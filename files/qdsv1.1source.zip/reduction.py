from math import sin
from math import cos
from math import tan
from math import atan
from math import sqrt
from math import radians
from math import degrees
from vincenty import Vincenty
from read_deflection import get_dov
from coordinate_conversion import geodetic_to_enu


class AzimuthReduction:
    def __init__(self, azi, lat1, lon1, hgt1, lat2, lon2, hgt2, skew_normal=True, gravimetric=True,
                 normal_geodesic=True, to_ellipsoid=True, a=6378137.0, f=1/298.257223563):
        self.major_radii = a
        self.flattening = f
        self.minor_radii = a - (a * f)
        self.eccentricity = sqrt((self.major_radii**2 - self.minor_radii**2) / self.major_radii**2)
        e = self.eccentricity
        lat1, lon1, lat2, lon2, azi = map(radians, [lat1, lon1, lat2, lon2, azi])

        # gravimetric correction
        xi_p, eta_p = get_dov(degrees(lat1), degrees(lon1))
        xi_p, eta_p = map(radians, [xi_p / 3600, eta_p / 3600])
        x_east, y_north, z_up = geodetic_to_enu(lat=lat2, lon=lon2, hgt=hgt2, lat0=lat1, lon0=lon1, hgt0=hgt1,
                                                is_degree=False)
        z_dist = radians(90 - degrees(atan(z_up / sqrt(x_east**2 + y_north**2))))
        dho_t = -(xi_p * sin(azi) - eta_p * cos(azi)) * (1 / tan(z_dist))
        dho_t = degrees(dho_t) * 3600
        if abs(dho_t) < 1e-2:
            dho_t = 0

        # skew normal correction
        m1 = a * (1 - (e**2)) / (1 - (e**2) * (sin(lat1)**2))**1.5
        m2 = a * (1 - (e**2)) / (1 - (e**2) * (sin(lat2)**2))**1.5
        mm = (m1 + m2) / 2
        dho_h = (hgt2 / mm) * (e**2) * sin(azi) * cos(azi) * (cos(lat2)**2)
        dho_h = degrees(dho_h) * 3600
        if abs(dho_h) < 1e-2:
            dho_h = 0

        # normal-geodesic correction
        s = Vincenty(coord1=(degrees(lat1), degrees(lon1)), coord2=(degrees(lat2), degrees(lon2))).meters
        latm = (lat1 + lat2) / 2
        n1 = a / (1 - (e**2) * (sin(lat1)**2))**0.5
        n2 = a / (1 - (e**2) * (sin(lat2)**2))**0.5
        nm = (n1 + n2) / 2
        dho_g = (e**2) * (s**2) * (cos(latm)**2) * sin(2 * azi) / (12 * (nm ** 2))
        dho_g = degrees(dho_g) * 3600
        if abs(dho_g) < 1e-2:
            dho_g = 0

        if gravimetric:
            if to_ellipsoid:
                azi = azi + radians(dho_t / 3600)
                self.gravimetric_correction = dho_t
            else:
                azi = azi - radians(dho_t / 3600)
                self.gravimetric_correction = -dho_t
        if skew_normal:
            if to_ellipsoid:
                azi = azi + radians(dho_h / 3600)
                self.skew_normal_correction = dho_h
            else:
                azi = azi - radians(dho_h / 3600)
                self.skew_normal_correction = -dho_h
        if normal_geodesic:
            if to_ellipsoid:
                azi = azi + radians(dho_g / 3600)
                self.normal_geodesic_correction = dho_g
            else:
                azi = azi - radians(dho_g / 3600)
                self.normal_geodesic_correction = -dho_g

        self.corrected_azimuth_radians = azi
        self.corrected_azimuth_degrees = degrees(azi)
