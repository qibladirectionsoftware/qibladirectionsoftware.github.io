from math import sin
from math import cos
from math import radians
from math import degrees


def geodetic_to_ecef(lat, lon, h, is_degree=True, a=6378137.0, f=1/298.257223563):
    e_sq = f * (2 - f)
    if is_degree:
        lat, lon = map(radians, [lat, lon])
    N = a / (1 - e_sq * (sin(lat)**2))**0.5
    sin_lat = sin(lat)
    cos_lat = cos(lat)
    sin_lon = sin(lon)
    cos_lon = cos(lon)

    x = (h + N) * cos_lat * cos_lon
    y = (h + N) * cos_lat * sin_lon
    z = (h + (1 - e_sq) * N) * sin_lat

    return x, y, z


def ecef_to_enu(x, y, z, lat0, lon0, hgt0):
    lat0, lon0 = map(radians, [lat0, lon0])
    x0, y0, z0 = geodetic_to_ecef(lat=lat0, lon=lon0, h=hgt0, is_degree=False)
    xd = x - x0
    yd = y - y0
    zd = z - z0
    sin_lam = sin(lon0)
    cos_lam = cos(lon0)
    sin_phi = sin(lat0)
    cos_phi = cos(lat0)

    x_east = (-sin_lam * xd) + (cos_lam * yd)
    y_north = (-sin_phi * cos_lam * xd) - (sin_phi * sin_lam * yd) + (cos_phi * zd)
    z_up = (cos_phi * cos_lam * xd) + (cos_phi * sin_lam * yd) + (sin_phi * zd)

    return x_east, y_north, z_up


def geodetic_to_enu(lat, lon, hgt, lat0, lon0, hgt0, is_degree=True):
    x, y, z = geodetic_to_ecef(lat, lon, hgt, is_degree=is_degree)
    if not is_degree:
        lat0, lon0 = map(degrees, [lat0, lon0])
    return ecef_to_enu(x, y, z, lat0, lon0, hgt0)
