class Degree:
    def __init__(self, dd=0, dms=(0, 0, 0)):
        self.dd = dd
        self.dms = dms
        self.is_positive = True

    def dd2dms(self):
        is_positive = self.dd >= 0
        dd = abs(self.dd)
        minutes, seconds = divmod(dd * 3600, 60)
        degrees, minutes = divmod(minutes, 60)
        degrees = degrees if is_positive else -degrees
        if degrees == 0 and minutes != 0:
            minutes = minutes if is_positive else -minutes
        if degrees == 0 and minutes == 0:
            seconds = seconds if is_positive else -seconds
        self.dms = (int(degrees), int(minutes), seconds)
        return self.dms

    def dms2dd(self):
        if sum([self.dms[0], self.dms[1]/60, self.dms[2]/3600]) >= 0:
            self.is_positive = True
        else:
            self.is_positive = False
        c = [abs(self.dms[n])*60**-n for n in range(len(self.dms))]
        c = sum(c) if self.is_positive else -sum(c)
        self.dd = c
        return self.dd
