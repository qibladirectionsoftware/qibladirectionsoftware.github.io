from netCDF4 import Dataset
import numpy as np
from scipy.interpolate import interp2d


def get_dov(lat1, lon1):
    fname = 'QDS.nc'
    ncfid = Dataset(fname)
    lat = ncfid.variables['lat'][:].data
    lon = ncfid.variables['lon'][:].data
    eta = ncfid.variables['eta'][:].data
    xi = ncfid.variables['xi'][:].data

    tb = lat[lat > lat1][0]
    bb = lat[lat < lat1][-1]
    rb = lon[lon > lon1][0]
    lb = lon[lon < lon1][-1]

    xi_grid = [xi[np.where(lon == lb)[0][1], np.where(lat == bb)[1][0]],
               xi[np.where(lon == lb)[0][1], np.where(lat == tb)[1][0]],
               xi[np.where(lon == rb)[0][1], np.where(lat == bb)[1][0]],
               xi[np.where(lon == rb)[0][1], np.where(lat == tb)[1][0]]
               ]
    eta_grid = [eta[np.where(lon == lb)[0][1], np.where(lat == bb)[1][0]],
                eta[np.where(lon == lb)[0][1], np.where(lat == tb)[1][0]],
                eta[np.where(lon == rb)[0][1], np.where(lat == bb)[1][0]],
                eta[np.where(lon == rb)[0][1], np.where(lat == tb)[1][0]]
                ]
    f_xi = interp2d(x=[lb, lb, rb, rb], y=[bb, tb, bb, tb], z=xi_grid)
    f_eta = interp2d(x=[lb, lb, rb, rb], y=[bb, tb, bb, tb], z=eta_grid)
    xi_p = f_xi(lon1, lat1)[0]
    eta_p = f_eta(lon1, lat1)[0]
    return xi_p, eta_p
