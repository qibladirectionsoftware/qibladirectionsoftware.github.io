from PyQt5 import QtWidgets, QtCore, QtGui
from convert_degrees import Degree
from vincenty import Vincenty
from reduction import AzimuthReduction
from io_file_lib import file_saver, create_report
import os
import sys
import subprocess


class QiblaMain(QtWidgets.QWidget):
    def __init__(self):
        super().__init__()
        self.setGeometry(300, 400, 300, 400)  # set window size
        self.setWindowTitle('QDS-ITB')  # set title
        self.setWindowIcon(QtGui.QIcon('qibla.ico'))  # set icon

        self.mecca_crd = ((21, 25, 20.95), (39, 49, 34.34), 282.202)  # lat, lon, hgt
        self.output_file_path = []
        self.azi_1k_terrain = []
        self.azi_12_terrain = []
        self.beta_k12_terrain = []
        self.d_1k_ellipsoid = []

        self.init_ui()

    def init_ui(self):
        # input selection label
        input_selection_label = QtWidgets.QLabel('Jenis koordinat input:')

        # input selection combobox
        self.input_selection_combo_box = QtWidgets.QComboBox()
        self.input_selection_combo_box.addItem('Derajat desimal')
        self.input_selection_combo_box.addItem('Derajat menit detik')

        # input selection layout
        input_selection_layout = QtWidgets.QVBoxLayout()
        input_selection_layout.addWidget(input_selection_label)
        input_selection_layout.addWidget(self.input_selection_combo_box)

        # input selection layout 2
        input_selection_layout_2 = QtWidgets.QHBoxLayout()
        input_selection_layout_2.addLayout(input_selection_layout)
        input_selection_layout_2.addStretch()

        # input geodetic coordinate one
        coord_one_group_box = QtWidgets.QGroupBox('Koordinat Titik Berdiri Alat')
        lat_one_label = QtWidgets.QLabel('Lintang (derajat):')
        lon_one_label = QtWidgets.QLabel('Bujur (derajat):')
        hgt_one_label = QtWidgets.QLabel('Tinggi ellipsoid (meter):')
        lat_one_hlayout = QtWidgets.QHBoxLayout()
        lon_one_hlayout = QtWidgets.QHBoxLayout()
        hgt_one_hlayout = QtWidgets.QHBoxLayout()
        coord_one_vlayout = QtWidgets.QVBoxLayout()
        self.lat_one_line_edit = QtWidgets.QLineEdit()
        self.lon_one_line_edit = QtWidgets.QLineEdit()
        self.hgt_one_line_edit = QtWidgets.QLineEdit()

        self.lat_one_line_edit.setAlignment(QtCore.Qt.AlignCenter)
        self.lat_one_line_edit.setFixedSize(140, 20)
        self.lon_one_line_edit.setAlignment(QtCore.Qt.AlignCenter)
        self.lon_one_line_edit.setFixedSize(140, 20)
        self.hgt_one_line_edit.setAlignment(QtCore.Qt.AlignCenter)
        self.hgt_one_line_edit.setFixedSize(140, 20)

        lat_one_hlayout.addWidget(lat_one_label)
        lat_one_hlayout.addStretch()
        lat_one_hlayout.addWidget(self.lat_one_line_edit)
        lon_one_hlayout.addWidget(lon_one_label)
        lon_one_hlayout.addStretch()
        lon_one_hlayout.addWidget(self.lon_one_line_edit)
        hgt_one_hlayout.addWidget(hgt_one_label)
        hgt_one_hlayout.addStretch()
        hgt_one_hlayout.addWidget(self.hgt_one_line_edit)

        coord_one_vlayout.addLayout(lat_one_hlayout)
        coord_one_vlayout.addLayout(lon_one_hlayout)
        coord_one_vlayout.addLayout(hgt_one_hlayout)

        coord_one_group_box.setLayout(coord_one_vlayout)

        # input geodetic coordinate two
        coord_two_group_box = QtWidgets.QGroupBox('Koordinat Titik Pandangan Belakang')
        lat_two_label = QtWidgets.QLabel('Lintang (derajat):')
        lon_two_label = QtWidgets.QLabel('Bujur (derajat):')
        hgt_two_label = QtWidgets.QLabel('Tinggi ellipsoid (meter):')
        lat_two_hlayout = QtWidgets.QHBoxLayout()
        lon_two_hlayout = QtWidgets.QHBoxLayout()
        hgt_two_hlayout = QtWidgets.QHBoxLayout()
        coord_two_vlayout = QtWidgets.QVBoxLayout()
        self.lat_two_line_edit = QtWidgets.QLineEdit()
        self.lon_two_line_edit = QtWidgets.QLineEdit()
        self.hgt_two_line_edit = QtWidgets.QLineEdit()

        self.lat_two_line_edit.setAlignment(QtCore.Qt.AlignCenter)
        self.lat_two_line_edit.setFixedSize(140, 20)
        self.lon_two_line_edit.setAlignment(QtCore.Qt.AlignCenter)
        self.lon_two_line_edit.setFixedSize(140, 20)
        self.hgt_two_line_edit.setAlignment(QtCore.Qt.AlignCenter)
        self.hgt_two_line_edit.setFixedSize(140, 20)

        lat_two_hlayout.addWidget(lat_two_label)
        lat_two_hlayout.addStretch()
        lat_two_hlayout.addWidget(self.lat_two_line_edit)
        lon_two_hlayout.addWidget(lon_two_label)
        lon_two_hlayout.addStretch()
        lon_two_hlayout.addWidget(self.lon_two_line_edit)
        hgt_two_hlayout.addWidget(hgt_two_label)
        hgt_two_hlayout.addStretch()
        hgt_two_hlayout.addWidget(self.hgt_two_line_edit)

        coord_two_vlayout.addLayout(lat_two_hlayout)
        coord_two_vlayout.addLayout(lon_two_hlayout)
        coord_two_vlayout.addLayout(hgt_two_hlayout)

        coord_two_group_box.setLayout(coord_two_vlayout)

        # input coord layout
        input_coord_layout = QtWidgets.QHBoxLayout()
        input_coord_layout.addWidget(coord_one_group_box)
        input_coord_layout.addWidget(coord_two_group_box)

        # calculate button
        calc_button = QtWidgets.QPushButton('Hitung')
        calc_button.setFixedSize(100, 75)
        calc_button.clicked.connect(self.calc_button_clicked)

        # output file button
        create_output_button = QtWidgets.QPushButton('Buat File Output')
        create_output_button.clicked.connect(self.create_output_button_clicked)

        # open output folder
        open_output_folder_button = QtWidgets.QPushButton('Buka Folder Output')
        open_output_folder_button.clicked.connect(self.open_output_folder_button_clicked)

        # create copyright label
        copyright_label = QtWidgets.QLabel()
        copyright_label.setText('© Kelompok Keilmuan Geodesi - Institut Teknologi Bandung')
        my_font = QtGui.QFont()
        my_font.setBold(True)
        copyright_label.setFont(my_font)

        # create textbox
        self.result_textbox = QtWidgets.QTextEdit()
        self.result_textbox.setReadOnly(True)
        self.result_textbox.setFont(my_font)

        # button layout
        button_layout = QtWidgets.QVBoxLayout()
        button_layout.addWidget(create_output_button)
        button_layout.addWidget(calc_button)

        # button and text box layout
        button_layout_2 = QtWidgets.QHBoxLayout()
        button_layout_2.addWidget(self.result_textbox)
        button_layout_2.addLayout(button_layout)

        # entire layout
        first_layout = QtWidgets.QVBoxLayout()
        first_layout.addLayout(input_selection_layout_2)
        first_layout.addLayout(input_coord_layout)
        first_layout.addStretch()
        first_layout.addLayout(button_layout_2)
        first_layout.addWidget(copyright_label)

        self.update_textbox()
        self.setLayout(first_layout)
        self.show()

    def read_dms(self, text):
        if text.__contains__('-'):
            dms_negative = True
        else:
            dms_negative = False
        text = text.split(',')
        d, m, s = map(float, text)
        decimal_degree = Degree(dms=(d, m, s)).dms2dd()
        if decimal_degree > 0 and dms_negative:
            decimal_degree = -decimal_degree
        return decimal_degree

    def update_textbox(self):
        ds = u'\u00b0'
        a1 = self.azi_1k_terrain
        b1 = self.beta_k12_terrain
        c1 = self.d_1k_ellipsoid
        self.result_textbox.setPlainText('')
        if a1:
            self.result_textbox.append(f'Arah kiblat masjid')
            self.result_textbox.append(f'>>> {a1[0]:3d}{ds} {a1[1]:2d}\' {a1[2]:2.2f}"')
            self.result_textbox.append(f'\n')
            self.result_textbox.append(f'Sudut rekonstruksi')
            self.result_textbox.append(f'>>> {b1[0]:3d}{ds} {b1[1]:2d}\' {b1[2]:2.2f}"')
            self.result_textbox.append(f'\n')
            self.result_textbox.append(f'Jarak ke Kakbah (kilometer)')
            self.result_textbox.append(f'>>> {c1:12.6f} kilometer')
        else:
            self.result_textbox.append(f'Arah kiblat masjid')
            self.result_textbox.append(f'>>>')
            self.result_textbox.append(f'\n')
            self.result_textbox.append(f'Sudut rekonstruksi')
            self.result_textbox.append(f'>>>')
            self.result_textbox.append(f'\n')
            self.result_textbox.append(f'Jarak ke Kakbah (kilometer)')
            self.result_textbox.append(f'>>>')


    def error_message_happens(self, err_msg):
        error_list = [
            'could not convert string to float',
            'not enough values to unpack'
        ]
        error_pop = QtWidgets.QMessageBox()
        error_pop.setWindowIcon(QtGui.QIcon('qibla.ico'))
        error_pop.setIcon(QtWidgets.QMessageBox.Critical)
        error_pop.setWindowTitle('Error')
        if err_msg.__contains__(error_list[0]):
            error_pop.setText('Jenis input salah atau kurang, masukkan koordinat dalam format yang benar atau '
                              'lengkapi seluruh input.')
        elif err_msg.__contains__(error_list[1]):
            error_pop.setText('Masukkan nilai koordinat lintang atau bujur dengan format "derajat, menit, detik".')
        else:
            error_pop.setText(err_msg)
        error_pop.exec_()

    def open_output_folder_button_clicked(self):
        target_folder = os.getcwd()
        cmd = 'explorer "' + target_folder + '"'
        subprocess.Popen(cmd)

    def create_output_button_clicked(self):
        self.output_file_path = file_saver(False, 'Tentukan output file laporan', '',
                                           'Report File (*.qrpt)')

    def calc_button_clicked(self):
        inp_mode = int(self.input_selection_combo_box.currentIndex())
        lat_q, lon_q, hgt_q = Degree(dms=self.mecca_crd[0]).dms2dd(), \
                              Degree(dms=self.mecca_crd[1]).dms2dd(), \
                              self.mecca_crd[2]
        if inp_mode == 0:
            try:
                lat_1, lon_1, hgt_1 = float(self.lat_one_line_edit.text()), float(self.lon_one_line_edit.text()), \
                                      float(self.hgt_one_line_edit.text())
                lat_2, lon_2, hgt_2 = float(self.lat_two_line_edit.text()), float(self.lon_two_line_edit.text()), \
                                      float(self.hgt_two_line_edit.text())
            except ValueError as error_msg:
                error_msg = str(error_msg)
                self.error_message_happens(error_msg)
                return

        if inp_mode == 1:
            try:
                lat_1, lon_1, hgt_1 = self.read_dms(self.lat_one_line_edit.text()), \
                                      self.read_dms(self.lon_one_line_edit.text()), \
                                      float(self.hgt_one_line_edit.text())
                lat_2, lon_2, hgt_2 = self.read_dms(self.lat_two_line_edit.text()), \
                                      self.read_dms(self.lon_two_line_edit.text()), \
                                      float(self.hgt_two_line_edit.text())
            except ValueError as error_msg:
                error_msg = str(error_msg)
                self.error_message_happens(error_msg)
                return

        try:
            if not self.output_file_path:
                raise OSError('File output belum ditentukan.')
        except OSError as error_msg:
            error_msg = str(error_msg)
            self.error_message_happens(error_msg)
            return

        # lat_1, lon_1, hgt_1 = -7.05650114, 107.57942239, 692.316
        # lat_2, lon_2, hgt_2 = -7.05695985, 107.57957823, 692.990

        # lat_1, lon_1, hgt_1 = -7.05651671, 108.05043990, 628.250
        # lat_2, lon_2, hgt_2 = -7.05684159, 108.05026474, 630.318

        if (lat_1 > 15 or lat_2 > 15) or (lat_1 < -15 or lat_2 < -15) or (lon_1 > 150 or lon_2 > 150) or \
                (lon_1 < 90 or lon_2 < 90):
            error_msg = str('Titik berdiri alat berada di luar jangkauan.\n'
                            'Koordinat harus memenuhi kondisi berikut.\n'
                            '-15 < Lintang < 15 dan 90 < Bujur < 150.')
            self.error_message_happens(error_msg)
            return

        alpha_1k_ellipsoid = Vincenty((lat_1, lon_1), (lat_q, lon_q)).forward_azimuth
        alpha_12_ellipsoid = Vincenty((lat_1, lon_1), (lat_2, lon_2)).forward_azimuth

        point_1_to_k = AzimuthReduction(azi=alpha_1k_ellipsoid, lat1=lat_1, lon1=lon_1, hgt1=hgt_1, lat2=lat_q,
                                        lon2=lon_q, hgt2=hgt_q, skew_normal=True, normal_geodesic=True,
                                        gravimetric=True, to_ellipsoid=False)
        alpha_1k_terrain = point_1_to_k.corrected_azimuth_degrees
        alpha_1k_correction = [point_1_to_k.gravimetric_correction, point_1_to_k.skew_normal_correction,
                               point_1_to_k.normal_geodesic_correction]

        point_1_to_2 = AzimuthReduction(azi=alpha_12_ellipsoid, lat1=lat_1, lon1=lon_1, hgt1=hgt_1, lat2=lat_2,
                                        lon2=lon_2, hgt2=hgt_2, skew_normal=True, normal_geodesic=True,
                                        gravimetric=True, to_ellipsoid=False)
        alpha_12_terrain = point_1_to_2.corrected_azimuth_degrees
        alpha_12_correction = [point_1_to_2.gravimetric_correction, point_1_to_2.skew_normal_correction,
                               point_1_to_2.normal_geodesic_correction]

        beta_ellipsoid = alpha_1k_ellipsoid - alpha_12_ellipsoid
        beta_terrain = alpha_1k_terrain - alpha_12_terrain
        # change negative angle to positive (right handed system)
        if beta_ellipsoid < 0:
            beta_ellipsoid += 360
        if beta_terrain < 0:
            beta_terrain += 360

        d_1k_ellipsoid = Vincenty((lat_1, lon_1), (lat_q, lon_q)).kilometers
        d_12_ellipsoid = Vincenty((lat_1, lon_1), (lat_2, lon_2)).kilometers

        self.azi_1k_terrain = Degree(dd=alpha_1k_terrain).dd2dms()
        self.azi_12_terrain = Degree(dd=alpha_12_terrain).dd2dms()
        self.beta_k12_terrain = Degree(dd=beta_terrain).dd2dms()
        self.d_1k_ellipsoid = d_1k_ellipsoid

        self.update_textbox()

        create_report(self.output_file_path[0], crd1=[lat_1, lon_1, hgt_1], crd2=[lat_2, lon_2, hgt_2],
                      crdk=self.mecca_crd, azi_1k=alpha_1k_terrain, azi_12=alpha_12_terrain,
                      beta=beta_terrain, azi_1k_correction=alpha_1k_correction, azi_12_correction=alpha_12_correction,
                      d_AK=d_1k_ellipsoid, d_AB=d_12_ellipsoid)


if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    ex = QiblaMain()
    sys.exit(app.exec_())
