from PyQt5 import QtWidgets, QtCore
from convert_degrees import Degree


def convert_to_native_path(path_list):
    new_file_path = list()
    if isinstance(path_list, (list,)):
        for nama in path_list:
            temp = QtCore.QDir.toNativeSeparators(nama)
            new_file_path.append(temp)
    else:
        new_file_path.append(QtCore.QDir.toNativeSeparators(path_list))
    return new_file_path


def file_saver(f_multiple, dialog_name, dialog_folder, f_type):
    options = QtWidgets.QFileDialog.Options()
    if f_multiple:
        file_path, _ = QtWidgets.QFileDialog.getSaveFileNames(None, dialog_name, dialog_folder,
                                                              f_type, options=options)
    else:
        file_path, _ = QtWidgets.QFileDialog.getSaveFileName(None, dialog_name, dialog_folder,
                                                             f_type, options=options)
    if file_path:
        f_path = convert_to_native_path(file_path)
        return f_path


def create_report(fname, crd1, crd2, crdk, azi_1k, azi_12, beta, azi_1k_correction, azi_12_correction, d_AK, d_AB):
    azi_1k = Degree(dd=azi_1k).dd2dms()
    azi_12 = Degree(dd=azi_12).dd2dms()
    beta = Degree(dd=beta).dd2dms()
    latk = Degree(dms=crdk[0]).dms2dd()
    lonk = Degree(dms=crdk[1]).dms2dd()
    hgtk = crdk[2]

    dt_1k = Degree(dd=azi_1k_correction[0] / 3600).dd2dms()
    dh_1k = Degree(dd=azi_1k_correction[1] / 3600).dd2dms()
    dg_1k = Degree(dd=azi_1k_correction[2] / 3600).dd2dms()
    dt_12 = Degree(dd=azi_12_correction[0] / 3600).dd2dms()
    dh_12 = Degree(dd=azi_12_correction[1] / 3600).dd2dms()
    dg_12 = Degree(dd=azi_12_correction[2] / 3600).dd2dms()

    ds = u'\u00b0'
    fid = open(fname, mode='w')
    fid.write(f'SIMBOL:\n')
    fid.write(f'# Titik berdiri alat                                                        : A\n')
    fid.write(f'# Titik pandangan belakang                                                  : B\n')
    fid.write(f'# Titik kakbah                                                              : K\n')
    fid.write(f'# Jarak elipsoid titik berdiri alat ke kakbah                               : d_AK\n')
    fid.write(f'# Jarak elipsoid titik berdiri alat ke pandangan belakang                   : d_AB\n')
    fid.write(f'# Sudut jurusan titik berdiri alat ke kakbah (terkoreksi)                   : alpha_AK\n')
    fid.write(f'# Sudut jurusan titik berdiri alat ke pandangan belakang (terkoreksi)       : alpha_AB\n')
    fid.write(f'# Koreksi irisan normal                                                     : dh\n')
    fid.write(f'# Koreksi geodesik normal                                                   : dg\n')
    fid.write(f'# Koreksi defleksi vertikal                                                 : dt\n')
    fid.write(f'# Sudut dari arah pandangan belakang ke arah kakbah                         : beta\n')
    fid.write('\n')
    fid.write(f'KOORDINAT (LINTANG, BUJUR, TINGGI):\n')
    fid.write(f'# A : {crd1[0]:12.8f}{ds}, {crd1[1]:12.8f}{ds}, {crd1[2]:8.3f}m\n')
    fid.write(f'# B : {crd2[0]:12.8f}{ds}, {crd2[1]:12.8f}{ds}, {crd2[2]:8.3f}m\n')
    fid.write(f'# K : {latk:12.8f}{ds}, {lonk:12.8f}{ds}, {hgtk:8.3f}m\n')
    fid.write('\n')
    fid.write(f'JARAK ELIPSOID:\n')
    fid.write(f'# d_AK : {d_AK:12.3f} meter\n')
    fid.write(f'# d_AB : {d_AB:12.3f} meter\n')
    fid.write('\n')    
    fid.write(f'SUDUT JURUSAN (TERKOREKSI):\n')
    fid.write(f'# alpha_AK : {azi_1k[0]:3d}{ds} {azi_1k[1]:2d}\' {azi_1k[2]:2.2f}"\n')
    fid.write(f'# alpha_AB : {azi_12[0]:3d}{ds} {azi_12[1]:2d}\' {azi_12[2]:2.2f}"\n')
    fid.write('\n')
    fid.write(f'SUDUT REKONSTRUKSI:\n')
    fid.write(f'# beta : {beta[0]:3d}{ds} {beta[1]:2d}\' {beta[2]:2.2f}"\n')
    fid.write(f'\n')
    fid.write(f'KETERANGAN KOREKSI REDUKSI ELIPSOID KE PERMUKAAN BUMI:\n')
    fid.write(f'# dh untuk alpha_AK : {dh_1k[0]:3d}{ds} {dh_1k[1]:2d}\' {dh_1k[2]:4.2f}"\n')
    fid.write(f'# dg untuk alpha_AK : {dg_1k[0]:3d}{ds} {dg_1k[1]:2d}\' {dg_1k[2]:4.2f}"\n')
    fid.write(f'# dt untuk alpha_AK : {dt_1k[0]:3d}{ds} {dt_1k[1]:2d}\' {dt_1k[2]:4.2f}"\n')
    fid.write(f'# dh untuk alpha_AB : {dh_12[0]:3d}{ds} {dh_12[1]:2d}\' {dh_12[2]:4.2f}"\n')
    fid.write(f'# dg untuk alpha_AB : {dg_12[0]:3d}{ds} {dg_12[1]:2d}\' {dg_12[2]:4.2f}"\n')
    fid.write(f'# dt untuk alpha_AB : {dt_12[0]:3d}{ds} {dt_12[1]:2d}\' {dt_12[2]:4.2f}"\n')

    fid.close()


