% konversi ECEF2LLA / geos2geod
% geosentrik ke geodetik
% KKGD 6 Oktober 2017
% input:
% X Y Z geosentrik dalam meter
% a = semi major axis dalam meter
% e = eksentrisitas
% output:
% phi lamda dalam derajat
% h dalam meter
%
% Referensi:
% A Comparison of Method Used in Rectangular to Geodetic
% Coordinate Transformations (Bowring's Iterative Method p5-p10)
% Robert Burtch (2006)
% ==============================================================

function [philamdaH]=geos2geod(XYZ,a,e)

X=XYZ(1);
Y=XYZ(2);
Z=XYZ(3);

if (nargin<3)
    %wgs84 ellipsoid default
    a= 6378137; %m
    e= 0.0818191908426215;
end

lamda=atan2d(Y,X);
%b=a*sqrt(1-e^2);
p=sqrt(X^2+Y^2);
%R=sqrt(X^2+Y^2+Z^2);
%e2=sqrt((a^2-b^2)/b^2);

%{
%close formula
beta=atandd(Z*a/(p*b));
phi=atandd((Z+b*e2^2*sindd(beta)^3)/(p-a*e^2*cosdd(beta)^3));
N=a/sqrt(1-e^2*sindd(phi)^2);
h=(p/cosdd(phi))-N;
%}

%iteratif
h0=0;
phi0=atand(Z/(p*(1-e^2)));
N=a/sqrt(1-e^2*sind(phi0)^2);
h=(p/cosd(phi0))-N;
phi=atand(Z/(p*(1-(e^2*N/(N+h)))));
while abs(h-h0)>0.0000000001 && abs(phi-phi0)>0.00000001
    h0=h;phi0=phi;
    N=a/sqrt(1-e^2*sind(phi)^2);
    h=(p/cosd(phi))-N;
    phi=atand(Z/(p*(1-(e^2*N/(N+h)))));
end

philamdaH=[phi;lamda;h];

end