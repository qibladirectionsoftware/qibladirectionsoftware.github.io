% konversi LLA2ECEF / geod2geos
% geodetik ke geosentrik
% KKGD 6 Oktober 2017
% input:
% phi = lintang dalam derajat
% lamda = bujur dalam derajat 
% h = tinggi geodetik dalam meter
% a = semi major axis dalam meter
% e = eksentrisitas
%
% Referensi:
% Slide Kuliah Geodesi Geometrik 
% Kosasih P. & Wedyanto K. (2006) 
% ==========================================

function [XYZ]=geod2geos(philamdaH,a,e)

phi=philamdaH(1);
lamda=philamdaH(2);
h=philamdaH(3);

if (nargin<3)
    %wgs84 ellipsoid default
    a= 6378137; %m
    e= 0.0818191908426215;
end

N=a/sqrt(1-e^2.*sind(phi)^2);

X=(N+h).*cosd(phi).*cosd(lamda);
Y=(N+h).*cosd(phi).*sind(lamda);
Z=(N.*(1-e^2)+h).*sind(phi);

XYZ=[X;Y;Z];

end