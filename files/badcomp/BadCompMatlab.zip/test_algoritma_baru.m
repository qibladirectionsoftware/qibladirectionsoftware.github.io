%testing algoritma bad-comp baru
%28 februari 2018
%nur fajar

a_array = 6378137:10000:9378137;

for i=1:length(a_array)
    [eastingSementara,northingSementara,nilai_simpan]=latlonh2sementara(-6.890530,107.612023,758,-6.891453,107.612209,750,a_array(i));
    [lat,lon,H]=sementara2latlonH(eastingSementara,northingSementara,nilai_simpan.r0,nilai_simpan.lon0,nilai_simpan.transXYZ);
    residu_lat(i)=abs(lat--6.890530);
    residu_lon(i)=abs(lon-107.612023);
    residu_H(i)=abs(H-758);
end
