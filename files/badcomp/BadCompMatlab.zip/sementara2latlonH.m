% fungsi untuk transformasi koordinat sistem koordinat sementara ke wgs84
% modifikasi dari algoritma pak piping
% nur fajar 
% 26 Februari 2018

function [lat,lon,H]=sementara2latlonH(eastingSementara,northingSementara,r0,lon0,transXYZ)

%parameter
a_wgs84 = 6378137;
e_wgs84 = 0.0818191908426215;

%geodetik sementara
[latlonH_sementara]=TM2geod([eastingSementara,northingSementara],lon0,r0,0);

%geosentrik sementara
[xyz_sementara]=geod2geos([latlonH_sementara;0],r0,0);

%geosentrik nasional
if northingSementara < 0 %selatan ekuator
    xyz_nasional = xyz_sementara-transXYZ;
elseif northingSementara > 0 %utara ekuator
    xyz_nasional = xyz_sementara+transXYZ;
end

%geodetik nasional
[latlonH]=geos2geod(xyz_nasional,a_wgs84,e_wgs84);

%simpan nilai variabel
lat = latlonH(1);
lon = latlonH(2);
H = latlonH(3);

end