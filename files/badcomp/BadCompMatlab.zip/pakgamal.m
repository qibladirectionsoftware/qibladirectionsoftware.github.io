clear;clc
%ke toposentrik
wgs84=referenceEllipsoid('wgs84','meters');
lbh_141=[-6.89092328888889,107.61234715277800,789.2737];
lbh_134=[-6.89110258055555,107.61039444722200,788.8369];
lbh_140=[-6.88918060277778,107.61253200277800,793.8947];

%cek apakah jarak toposentrik sama dengan ETS
[e,n,u]=geodetic2enu(lbh_134(1),lbh_134(2),lbh_134(3),lbh_141(1),lbh_141(2),lbh_141(3),wgs84); %134
jarak_141_134_topo=sqrt(e^2+n^2+u^2)
[e2,n2,u2]=geodetic2enu(lbh_140(1),lbh_140(2),lbh_140(3),lbh_141(1),lbh_141(2),lbh_141(3),wgs84); %140
jarak_141_140_topo=sqrt(e2^2+n2^2+u2^2)
%====================================================================
%sementara
%titik 141
[x_sem,y_sem]=latlonh2sementara(lbh_141(1),lbh_141(2),lbh_141(3),lbh_141(1),lbh_141(2),lbh_141(3),6378137);
%titik 134
[x2_sem,y2_sem]=latlonh2sementara(lbh_134(1),lbh_134(2),lbh_134(3),lbh_141(1),lbh_141(2),lbh_141(3),6378137);
%titik 140
[x3_sem,y3_sem]=latlonh2sementara(lbh_140(1),lbh_140(2),lbh_140(3),lbh_141(1),lbh_141(2),lbh_141(3),6378137);
%jarak 141 ke 134
jarak_141_134_sem=sqrt((x2_sem-x_sem)^2+(y2_sem-y_sem)^2)
%jarak 141 ke 140
jarak_141_140_sem=sqrt((x3_sem-x_sem)^2+(y3_sem-y_sem)^2)
%==================================================================
%UTM
[xutm141,yutm141]=ll2utm(lbh_141(1:2));
[xutm134,yutm134]=ll2utm(lbh_134(1:2));
[xutm140,yutm140]=ll2utm(lbh_140(1:2));
jarak_141_134_utm=sqrt((xutm141-xutm134)^2+(yutm141-yutm134)^2)
jarak_141_140_utm=sqrt((xutm141-xutm140)^2+(yutm141-yutm140)^2)
%===================================================================
[xytm3_141]=geod2TM3(lbh_141(1:2),106.5,wgs84.SemimajorAxis,wgs84.Eccentricity);
[xytm3_134]=geod2TM3(lbh_134(1:2),106.5,wgs84.SemimajorAxis,wgs84.Eccentricity);
[xytm3_140]=geod2TM3(lbh_140(1:2),106.5,wgs84.SemimajorAxis,wgs84.Eccentricity);
jarak_141_134_tm3=sqrt((xytm3_141(2)-xytm3_134(2))^2+(xytm3_141(1)-xytm3_134(1))^2)
jarak_141_140_tm3=sqrt((xytm3_141(2)-xytm3_140(2))^2+(xytm3_141(1)-xytm3_140(1))^2)