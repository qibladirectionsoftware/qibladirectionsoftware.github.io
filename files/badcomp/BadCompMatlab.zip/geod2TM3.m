% konversi llatoTM
% geodetik ke proyeksi TM
% KKGD 13 Oktober 2017
% input :
% phi lamda dalam derajat
% output:
% x dan y dalam meter
% 
% Referensi:
% EPSG Guidance page 29
% ==========================================

function [xy]=geod2TM3(philamda,lamda0,a,e)

k0=0.9999;
FalseE=200000;
FalseN=1500000;
phi0=0;

phi=philamda(1);
lamda=philamda(2);

if (nargin<4)
    %wgs84 ellipsoid default
    a= 6378137; %m
    e= 0.0818191908426215;
end
phi=deg2rad(phi);lamda=deg2rad(lamda);lamda0=deg2rad(lamda0);phi0=deg2rad(phi0);
b=a*sqrt(1-e^2);
e2=sqrt((a^2-b^2)/b^2);

T=tan(phi)^2;   
C=e^2*cos(phi)^2/(1-e^2);
A=(lamda-lamda0)*cos(phi);
N=a/sqrt(1-e^2*sin(phi)^2);
M=a*((1-e^2/4-3*e^4/64-5*e^6/256)*phi-(3*e^2/8+3*e^4/32+45*e^6/1024)*sin(2*phi)+(15*e^4/256+45*e^6/1024)*sin(4*phi)-(35*e^6/3072)*sin(6*phi));
M0=a*((1-e^2/4-3*e^4/64-5*e^6/256)*phi0-(3*e^2/8+3*e^4/32+45*e^6/1024)*sin(2*phi0)+(15*e^4/256+45*e^6/1024)*sin(4*phi0)-(35*e^6/3072)*sin(6*phi0));

E=N*(A+(1-T+C)*A^3/6+(5-18*T+T^2+72*C-58*e2^2)*A^5/120);
N=M-M0+N*tan(phi)*(A^2/2+(5-T+9*C+4*C^2)*A^4/24+(61-58*T+T^2+600*C-330*e2^2)*A^6/720);

x = FalseE+k0*E;
y = FalseN+k0*N;

xy=[x;y];

end
