% konversi TMtolla
% proyeksi TM ke geodetik
% KKGD 23 Oktober 2017
% input:
% x dan y dalam meter
% output :
% phi lamda dalam derajat
% 
% Referensi:
% EPSG Guidance page 29-30
% ==========================================

function [philamda]=TM2geod(xy,lamda0,a,e)

k0=1;
FalseE=0;
FalseN=0;
phi0=0;

x=xy(1);
y=xy(2);

if (nargin<4)
    %wgs84 ellipsoid default
    a= 6378137; %m
    e= 0.0818191908426215;
end
lamda0=deg2rad(lamda0);phi0=deg2rad(phi0);
b=a*sqrt(1-e^2);
e2=sqrt((a^2-b^2)/b^2);
e1=(1-sqrt(1-e^2))/(1+sqrt(1-e^2));

M0=a*((1-e^2/4-3*e^4/64-5*e^6/256)*phi0-(3*e^2/8+3*e^4/32+45*e^6/1024)*sin(2*phi0)+(15*e^4/256+45*e^6/1024)*sin(4*phi0)-(35*e^6/3072)*sin(6*phi0));
M1=M0+(y-FalseN)/k0;
u1=M1/(a*(1-e^2/4-3*e^4/64-5*e^6/256));
phi1= u1+(3*e1/2-27*e1^3/32)*sin(2*u1)+(21*e1^2/16-55*e1^4/32)*sin(4*u1)+(151*e1^3/96)*sin(6*u1)+(1097*e1^4/512)*sin(8*u1);%proyeksi cassini
T1=tan(phi1)^2;

C1=e2^2*cos(phi1)^2;
N1=a/sqrt(1-e^2*sin(phi1)^2);
D=(x-FalseE)/(N1*k0);

rho1=a*(1-e^2)/(1-e^2*sin(phi1)^2)^(3/2);
phi=phi1-(N1*tan(phi1)/rho1)*(D^2/2-(5+3*T1+10*C1-4*C1^2-9*e2^2)*D^4/24+(61+90*T1+298*C1+45*T1^2-252*e2^2-3*C1^2+8*e2^2)*D^6/720);
lamda=lamda0+(D-(1+2*T1+C1)*D^3/6+(5-2*C1+28*T1-3*C1^2+8*e2^2+24*T1^2)*D^5/120)/cos(phi1);
phi=rad2deg(phi);lamda=rad2deg(lamda);
philamda=[phi;lamda];
end