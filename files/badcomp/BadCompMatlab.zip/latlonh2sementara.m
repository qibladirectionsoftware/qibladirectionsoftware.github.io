% fungsi untuk transformasi koordinat wgs84 ke sistem koordinat sementara
% modifikasi dari algoritma pak piping
% nur fajar 
% 26 Februari 2018

function [eastingSementara,northingSementara,nilai_simpan]=latlonh2sementara(lat,lon,H,lat0,lon0,h0,a_sementara)
%memakai radius ellipsoid besar atau tidak
pakai = 1;

%parameter
a_wgs84 = 6378137;
e_wgs84 = 0.0818191908426215;
e_sementara = 0;

%geosentrik nasional
[xyz_nasional]=geod2geos([lat,lon,H],a_wgs84,e_wgs84);

%geosentrik sementara
N0=a_wgs84/(sqrt(1-e_wgs84^2*sind(lat0)^2));
zll=(N0*(1-e_wgs84^2))*sind(lat0);
if lat < 0 %selatan ekuator
    xyz_sementara = xyz_nasional-[0;0;(abs(N0*sind(lat0))-abs(zll))];
elseif lat > 0 %utara ekuator
    xyz_sementara = xyz_nasional-[0;0;(abs(N0*sind(lat0))-abs(zll))];
end

%tambah
if pakai
vektorTranslasi=[a_sementara*cosd(lat0)*cosd(lon0);
    a_sementara*cosd(lat0)*sind(lon0);
    a_sementara*sind(lat0)];
    xyz_sementara = xyz_sementara + vektorTranslasi;
end

%radius bola sementara
if pakai
    r0=N0+h0+a_sementara;
else
    r0=N0+h0;
end

%geodetik sementara
[latlonHS]=geos2geod([xyz_sementara(1),xyz_sementara(2),xyz_sementara(3)],r0,0);

%TM sementara
[xy_sementara]=geod2TM(latlonHS,lon0,r0,e_sementara);
eastingSementara=xy_sementara(1);
northingSementara=xy_sementara(2);

%simpan nilai variabel
nilai_simpan.r0 = r0;
nilai_simpan.lon0 = lon0;
nilai_simpan.transXYZ = xyz_sementara-xyz_nasional;
end