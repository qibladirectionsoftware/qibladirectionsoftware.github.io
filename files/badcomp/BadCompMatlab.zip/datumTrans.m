% datum transformation
% diketahui Rx, Ry, Rz dalam derajat
% dan Tx, Ty, Tz dalam meter serta S
% transformasi koordinat X,Y,Z (m) ke X,Y,Z (m) dengan helmert 3D
% Nur Fajar
% 23 Oktober 2017
% ====================================

function [xyz_baru] = datumTrans(vektorXYZ,vektorRotasi,vektorTranslasi,Scaling);

X1=vektorXYZ(1);Y1=vektorXYZ(2);Z1=vektorXYZ(3);
Rx=vektorRotasi(1);Ry=vektorRotasi(2);Rz=vektorRotasi(3);
Tx=vektorTranslasi(1);Ty=vektorTranslasi(2);Tz=vektorTranslasi(3);

Matriks_rot=[cosd(Ry)*cosd(Rz) cosd(Rx)*sind(Rz)+sind(Rx)*sind(Ry)*cosd(Rz) sind(Rx)*sind(Rz)-cosd(Rx)*sind(Ry)*cosd(Rz);
    -cosd(Ry)*sind(Rz) cosd(Rx)*cosd(Rz)-sind(Rx)*sind(Ry)*sind(Rz) sind(Rx)*cosd(Rz)+cosd(Rx)*sind(Ry)*sind(Rz);
    sind(Ry) -sind(Rx)*cosd(Ry) cosd(Rx)*cosd(Ry)];

xyz_baru=([Tx;Ty;Tz])+(Scaling*Matriks_rot)*[X1;Y1;Z1];

end