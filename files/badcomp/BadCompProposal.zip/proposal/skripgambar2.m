l=0:100:100000;
for i=1:length(l)
    S(i)=asin(l(i)/(2*6378137))*2*6378137;
end
plot(l/1000,(S-l)*100,'LineWidth',4)
xlabel('Jarak datar (km)','FontSize',13)
ylabel({'Kesalahan Akibat';'Kelengkungan Bumi (cm)'},'FontSize',13)
set(gca,'FontSize',15)