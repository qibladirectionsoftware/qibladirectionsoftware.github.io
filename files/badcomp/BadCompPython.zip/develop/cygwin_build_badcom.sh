#!/bin/bash

#cd "/cygdrive/d/Orang/Ppiping/BadCompPython/develop"
pyinstaller --noconfirm --log-level=WARN --clean --specpath build --onedir --windowed --runtime-hook="script/runtime_hooks/use_lib.py" script/badcomp_UI.py

mkdir dist/badcomp_UI/img
mkdir dist/badcomp_UI/lib
mkdir dist/badcomp_UI/windll
mv dist/badcomp_UI/*.pyd dist/badcomp_UI/lib/
mv dist/badcomp_UI/*.dll dist/badcomp_UI/windll/
mv dist/badcomp_UI/*.manifest dist/badcomp_UI/lib/
cp script/img/* dist/badcomp_UI/img/
while read p; do
  mv dist/badcomp_UI/windll/$p dist/badcomp_UI/$p
done <script/runtime_hooks/list

