# -*- coding: utf-8 -*-

import wx
import math
import wx.grid as gridlib

################################## Core Engine ########################################
def DD2DMS(DD):
    if DD < 0:
        negatif = 1
    else:
        negatif = 0 

    DD = math.fabs(DD)

    D=int(math.floor(DD))
    M=int(math.floor((DD-D)*60))
    S=math.floor(((M-((DD-D)*60))*60)*1000)/1000

    if negatif:
        DMS=[-D,M,S]
    else:
        DMS=[D,M,S]
    return DMS

def geod2geos(lat,lon,height,a,e):

    phi=math.radians(lat)
    lamda=math.radians(lon)
    h=height

    N=a/math.sqrt(1-math.pow(e,2)*math.pow(math.sin(phi),2))

    X=(N+h)*math.cos(phi)*math.cos(lamda)
    Y=(N+h)*math.cos(phi)*math.sin(lamda)
    Z=(N*(1-math.pow(e,2))+h)*math.sin(phi)

    XYZ=[X,Y,Z]
    return XYZ

def geos2geod(X,Y,Z,a,e):

    lamda=math.atan2(Y,X)
    p=math.sqrt(math.pow(X,2)+math.pow(Y,2))

    h0=0
    phi0=math.atan(Z/(p*(1-math.pow(e,2))))
    N=a/math.sqrt(1-math.pow(e,2)*math.pow(math.sin(phi0),2))
    h=(p/math.cos(phi0))-N
    phi=math.atan(Z/(p*(1-(math.pow(e,2)*N/(N+h)))))
    while math.fabs(h-h0)>0.0000000001 and math.fabs(phi-phi0)>0.00000001:
        h0=h
        phi0=phi
        N=a/math.sqrt(1-math.pow(e,2)*math.pow(math.sin(phi),2))
        h=(p/math.cos(phi))-N
        phi=math.atan(Z/(p*(1-(math.pow(e,2)*N/(N+h)))))

    philamdaH=[math.degrees(phi),math.degrees(lamda),h]
    return philamdaH

def geod2TM(phi,lamda,lamda0,a,e):

    k0=1
    FalseE=0
    FalseN=0
    phi0=0

    phi=math.radians(phi)
    lamda=math.radians(lamda)
    lamda0=math.radians(lamda0)
    phi0=math.radians(phi0)

    b=a*math.sqrt(1-math.pow(e,2))
    e2=math.sqrt((math.pow(a,2)-math.pow(b,2))/math.pow(b,2))

    T=math.pow(math.tan(phi),2)   
    C=math.pow(e,2)*math.pow(math.cos(phi),2)/(1-math.pow(e,2))
    A=(lamda-lamda0)*math.cos(phi)
    N=a/math.sqrt(1-math.pow(e,2)*math.pow(math.sin(phi),2))
    M=a*((1-math.pow(e,2)/4-3*math.pow(e,4)/64-5*math.pow(e,6)/256)*phi-(3*math.pow(e,2)/8+3*math.pow(e,4)/32+45*math.pow(e,6)/1024)*math.sin(2*phi)+(15*math.pow(e,4)/256+45*math.pow(e,6)/1024)*math.sin(4*phi)-(35*math.pow(e,6)/3072)*math.sin(6*phi))
    M0=a*((1-math.pow(e,2)/4-3*math.pow(e,4)/64-5*math.pow(e,6)/256)*phi0-(3*math.pow(e,2)/8+3*math.pow(e,4)/32+45*math.pow(e,6)/1024)*math.sin(2*phi0)+(15*math.pow(e,4)/256+45*math.pow(e,6)/1024)*math.sin(4*phi0)-(35*math.pow(e,6)/3072)*math.sin(6*phi0))

    E=N*(A+(1-T+C)*math.pow(A,3)/6+(5-18*T+math.pow(T,2)+72*C-58*math.pow(e2,2))*math.pow(A,5)/120)
    N=M-M0+N*math.tan(phi)*(math.pow(A,2)/2+(5-T+9*C+4*math.pow(C,2))*math.pow(A,4)/24+(61-58*T+math.pow(T,2)+600*C-330*math.pow(e2,2))*math.pow(A,6)/720)

    x=FalseE+k0*E
    y=FalseN+k0*N
    xy=[x,y]

    return xy

def TM2geod(x,y,lamda0,a,e):

    k0=1;
    FalseE=0;
    FalseN=0;
    phi0=0;

    lamda0=math.radians(lamda0)
    phi0=math.radians(phi0)

    b=a*math.sqrt(1-math.pow(e,2))
    e2=math.sqrt((math.pow(a,2)-math.pow(b,2))/math.pow(b,2))
    e1=(1-math.sqrt(1-math.pow(e,2)))/(1+math.sqrt(1-math.pow(e,2)))

    M0=a*((1-math.pow(e,2)/4-3*math.pow(e,4)/64-5*math.pow(e,6)/256)*phi0-(3*math.pow(e,2)/8+3*math.pow(e,4)/32+45*math.pow(e,6)/1024)*math.sin(2*phi0)+(15*math.pow(e,4)/256+45*math.pow(e,6)/1024)*math.sin(4*phi0)-(35*math.pow(e,6)/3072)*math.sin(6*phi0))
    M1=M0+(y-FalseN)/k0
    u1=M1/(a*(1-math.pow(e,2)/4-3*math.pow(e,4)/64-5*math.pow(e,6)/256))
    phi1= u1+(3*e1/2-27*math.pow(e1,3)/32)*math.sin(2*u1)+(21*math.pow(e1,2)/16-55*math.pow(e1,4)/32)*math.sin(4*u1)+(151*math.pow(e1,3)/96)*math.sin(6*u1)+(1097*math.pow(e1,4)/512)*math.sin(8*u1)
    T1=math.pow(math.tan(phi1),2)

    C1=math.pow(e2,2)*math.pow(math.cos(phi1),2)
    N1=a/math.sqrt(1-math.pow(e,2)*math.pow(math.sin(phi1),2))
    D=(x-FalseE)/(N1*k0)

    rho1=a*(1-math.pow(e,2))/math.pow((1-math.pow(e,2)*math.pow(math.sin(phi1),2)),(3/2))
    phi=phi1-(N1*math.tan(phi1)/rho1)*(math.pow(D,2)/2-(5+3*T1+10*C1-4*math.pow(C1,2)-9*math.pow(e2,2))*math.pow(D,4)/24+(61+90*T1+298*C1+45*math.pow(T1,2)-252*math.pow(e2,2)-3*math.pow(C1,2)+8*math.pow(e2,2))*math.pow(D,6)/720)
    lamda=lamda0+(D-(1+2*T1+C1)*math.pow(D,3)/6+(5-2*C1+28*T1-3*math.pow(C1,2)+8*math.pow(e2,2)+24*math.pow(T1,2))*math.pow(D,5)/120)/math.cos(phi1)
    
    phi=math.degrees(phi)
    lamda=math.degrees(lamda)
    
    philamda=[phi,lamda]

    return philamda

def latlonh2sementara(lat,lon,H,lat0,lon0,h0):

    lat0=math.radians(lat0)

    #parameter
    a_wgs84 = 6378137
    e_wgs84 = 0.0818191908426215
    e_sementara = 0

    #geosentrik nasional
    xyz_nasional=geod2geos(lat,lon,H,a_wgs84,e_wgs84)

    lat=math.radians(lat)
    lon=math.radians(lon)

    #geosentrik sementara
    N0=a_wgs84/(math.sqrt(1-math.pow(e_wgs84,2)*math.pow(math.sin(lat0),2)))
    zll=(N0*(1-math.pow(e_wgs84,2)))*math.sin(lat0)
    if lat < 0: #selatan ekuator
        xyz_sementara = [xyz_nasional[0]-0,xyz_nasional[1]-0,xyz_nasional[2]-((math.fabs(N0*math.sin(lat0))-math.fabs(zll)))]
    else: #utara ekuator
        xyz_sementara = [xyz_nasional[0]+0,xyz_nasional[1]+0,xyz_nasional[2]+((math.fabs(N0*math.sin(lat0))-math.fabs(zll)))]

    #radius bola sementara
    r0=N0+h0

    #geodetik sementara
    latlonHS=geos2geod(xyz_sementara[0],xyz_sementara[1],xyz_sementara[2],r0,e_sementara)

    #TM sementara
    xy_sementara=geod2TM(latlonHS[0],latlonHS[1],lon0,r0,e_sementara)
    eastingSementara=xy_sementara[0]
    northingSementara=xy_sementara[1]

    #simpan nilai variabel
    transXYZ = [xyz_sementara[0]-xyz_nasional[0],xyz_sementara[1]-xyz_nasional[1],xyz_sementara[2]-xyz_nasional[2]]

    output=[eastingSementara,northingSementara]

    return output

def sementara2latlonh(eastingSementara,northingSementara,lat0,lon0,h0):

    lat0=math.radians(lat0)

    #parameter
    a_wgs84 = 6378137
    e_wgs84 = 0.0818191908426215

    N0=a_wgs84/(math.sqrt(1-math.pow(e_wgs84,2)*math.pow(math.sin(lat0),2)))
    zll=(N0*(1-math.pow(e_wgs84,2)))*math.sin(lat0)
    transZ=0-((math.fabs(N0*math.sin(lat0))-math.fabs(zll)))

    #radius bola sementara
    r0=N0+h0

    #geodetik sementara
    latlonH_sementara=TM2geod(eastingSementara,northingSementara,lon0,r0,0)

    #geosentrik sementara
    xyz_sementara=geod2geos(latlonH_sementara[0],latlonH_sementara[1],0,r0,0)

    #geosentrik nasional
    if northingSementara < 0: #selatan ekuator
        xyz_nasional = [xyz_sementara[0],xyz_sementara[1],xyz_sementara[2]-transZ]
    else: #utara ekuator
        xyz_nasional = [xyz_sementara[0],xyz_sementara[1],xyz_sementara[2]+transZ]

    #geodetik nasional
    latlonH=geos2geod(xyz_nasional[0],xyz_nasional[1],xyz_nasional[2],a_wgs84,e_wgs84)

    output=[latlonH[0],latlonH[1]]

    return output

################################## User Interface ########################################

class Form2(wx.Panel):
    ''' The Form class is a wx.Panel that creates a bunch of controls
        and handlers for callbacks. Doing the layout of the controls is 
        the responsibility of subclasses (by means of the doLayout()
        method). '''

    def __init__(self, *args, **kwargs):
        super(Form2, self).__init__(*args, **kwargs)
        self.referrers = ['friends', 'advertising', 'websearch', 'yellowpages']
        self.colors = ['blue', 'red', 'yellow', 'orange', 'green', 'purple',
                       'navy blue', 'black', 'gray']
        self.coordSystem = ['GCS WGS 1984','TM Sementara SRGI 2013']
        self.createControls()
        self.createSheets(20)
        self.bindEvents()
        self.doLayout()

        self.LatCentral = float("-6.89092328888889")
        self.LongCentral = float("107.61234715277800")
        self.HeightCentral = float("789.2737")

        self.GunakanDefault = True
        self.DDDMS = 0

    def createSheets(self, rowsize):
        #GRID GCS
        self.GridGCS = gridlib.Grid(self)
        self.GridGCS.CreateGrid(rowsize, 3)
        self.GridGCS.SetCellValue(0,0, "101.12345678910")
        self.GridGCS.SetColLabelValue(0, "Lintang")
        self.GridGCS.SetColLabelValue(1, "Bujur")
        self.GridGCS.SetColLabelValue(2, "Tinggi")
        self.GridGCS.SetColSize(0, 130)
        self.GridGCS.SetColSize(1, 130)
        self.GridGCS.SetColSize(2, 130)
        for row in range(rowsize):
            self.GridGCS.SetRowLabelValue(row, "")
            for col in range(3):
                self.GridGCS.SetCellAlignment(row, col, wx.ALIGN_CENTRE,wx.ALIGN_CENTRE) 
        self.GridGCS.SetRowLabelSize(20)
        self.GridGCS.SetColLabelSize(20)
        self.GridGCS.SetColFormatFloat(0, width = 9, precision=5)
        self.GridGCS.SetColFormatFloat(1, width = 9, precision=5)
        self.GridGCS.SetColFormatFloat(2, width = 9, precision=5)

        #GRID PCS
        self.GridPCS = MyGrid(self)
        self.GridPCS.CreateGrid(rowsize, 2)
        self.GridPCS.SetCellValue(0,0, "90909.12345678910")
        self.GridPCS.SetColLabelValue(0, "Easting")
        self.GridPCS.SetColLabelValue(1, "Northing")
        self.GridPCS.SetColSize(0, 130)
        self.GridPCS.SetColSize(1, 130)
        for row in range(rowsize):
            self.GridPCS.SetRowLabelValue(row, "")
            for col in range(2):
                self.GridPCS.SetCellAlignment(row, col, wx.ALIGN_CENTRE,wx.ALIGN_CENTRE) 
        self.GridPCS.SetRowLabelSize(20)
        self.GridPCS.SetColLabelSize(20)
        self.GridPCS.SetColFormatFloat(0, width = 9, precision=5)
        self.GridPCS.SetColFormatFloat(1, width = 9, precision=5)

    def createControls(self):

        #tidak dipakai lagi
        self.saveButton = wx.Button(self, label="Save")
        self.nameLabel = wx.StaticText(self, label="Your name:")
        self.nameTextCtrl = wx.TextCtrl(self, value="Enter here your name")
        self.referrerLabel = wx.StaticText(self, 
            label="How did you hear from us?")
        self.referrerComboBox = wx.ComboBox(self, choices=self.referrers, 
            style=wx.CB_DROPDOWN)
        self.insuranceCheckBox = wx.CheckBox(self, 
            label="Do you want Insured Shipment?")
        self.colorRadioBox = wx.RadioBox(self, 
            label="What color would you like?", 
            choices=self.colors, majorDimension=3, style=wx.RA_SPECIFY_COLS)

        self.jumlahLabel = wx.StaticText(self, label="Jumlah titik:")
        self.jumlahTextCtrl = wx.TextCtrl(self, value="", size=(50, -1))
        self.dummy = wx.StaticText(self, label="")

        #button
        self.TransformButton = wx.Button(self, label="&Transformasi", size=(100, -1))
        self.TransformButton.SetBitmap(wx.Bitmap('img/cal.png'))
        self.ClearButton = wx.Button(self, label="&Hapus...", size=(100, -1))
        self.ClearButton.SetBitmap(wx.Bitmap('img/blank.png'))
        self.IsiButton = wx.Button(self, label="&Isi Contoh", size=(100, -1))
        self.IsiButton.SetBitmap(wx.Bitmap('img/pencil.png'))
        self.terapkanButton = wx.Button(self, label="T&erapkan", size=(100, -1))
        self.terapkanButton.SetBitmap(wx.Bitmap('img/apply.png'))

        #SK Sumber
        self.CSSourceLabel = wx.StaticText(self, 
            label="Sistem Koordinat Sumber:")
        self.CSSourceLabelGrid = wx.StaticText(self, 
            label="Sistem Koordinat WGS 84 ")
        self.CSSourceComboBox = wx.ComboBox(self, choices=self.coordSystem, value=self.coordSystem[0],
            style=wx.CB_DROPDOWN | wx.TE_READONLY, size=(305, -1))

        #SK Tujuan
        self.CSDestLabel = wx.StaticText(self, 
            label="Sistem Koordinat Tujuan:")
        self.CSDestLabelGrid = wx.StaticText(self, 
            label="Sistem Koordinat TM Sementara")
        self.CSDestComboBox = wx.ComboBox(self, choices=self.coordSystem, value=self.coordSystem[1],
            style=wx.CB_DROPDOWN | wx.TE_READONLY, size=(305, -1))

    def bindEvents(self):
        for control, event, handler in \
            [(self.saveButton, wx.EVT_BUTTON, self.onSave),
             (self.nameTextCtrl, wx.EVT_TEXT, self.onNameEntered),
             (self.nameTextCtrl, wx.EVT_CHAR, self.onNameChanged),
             (self.referrerComboBox, wx.EVT_COMBOBOX, self.onReferrerEntered),
             (self.referrerComboBox, wx.EVT_TEXT, self.onReferrerEntered),
             (self.insuranceCheckBox, wx.EVT_CHECKBOX, self.onInsuranceChanged),
             (self.colorRadioBox, wx.EVT_RADIOBOX, self.onColorchanged)]:
            control.Bind(event, handler)

    def doLayout(self):
        ''' Layout the controls that were created by createControls(). 
            Form.doLayout() will raise a NotImplementedError because it 
            is the responsibility of subclasses to layout the controls. '''
        raise NotImplementedError 

    # Callback methods:

    def onColorchanged(self, event):
        self.__log('User wants color: %s'%self.colors[event.GetInt()])

    def onReferrerEntered(self, event):
        self.__log('User entered referrer: %s'%event.GetString())

    def onSave(self,event):
        self.__log('User clicked on button with id %d'%event.GetId())

    def onNameEntered(self, event):
        self.__log('User entered name: %s'%event.GetString())

    def onNameChanged(self, event):
        self.__log('User typed character: %d'%event.GetKeyCode())
        event.Skip()

    def onInsuranceChanged(self, event):
        self.__log('User wants insurance: %s'%bool(event.Checked()))

    # Helper method(s):

    def __log(self, message):
        ''' Private method to append a string to the logger text
            control. '''
        #self.logger.AppendText('%s\n'%message)

class FormWithSizer2(Form2):
    def doLayout(self):

        #Sizer ultimate
        boxSizer = wx.BoxSizer(orient=wx.HORIZONTAL)

        #Sudah tidak dipakai
        gridSizer = wx.FlexGridSizer(rows=5, cols=2, vgap=10, hgap=10)

        #Sizer Kiri
        sizerMenuKiri = wx.FlexGridSizer(rows=3, cols=1, vgap=8, hgap=8)

        boxlabelPilihan = wx.StaticBox(self, -1, 'Sistem Koordinat:')
        boxPilihan = wx.StaticBoxSizer(boxlabelPilihan,wx.VERTICAL) 
        sizerPilihan = wx.FlexGridSizer(rows=4, cols=1, vgap=8, hgap=8)

        boxlabelJmlTitik = wx.StaticBox(self, -1, 'Opsi')
        boxJmlTitik = wx.StaticBoxSizer(boxlabelJmlTitik,wx.VERTICAL) 
        sizerJmlTitik = wx.FlexGridSizer(rows=1, cols=4, vgap=8, hgap=8)

        sizerButton = wx.FlexGridSizer(rows=2, cols=3, vgap=35, hgap=8)

        #Spreadsheetnyah
        SheetSizerSource = wx.FlexGridSizer(rows=2, cols=1, vgap=8, hgap=8)
        SheetSizerDest = wx.FlexGridSizer(rows=2, cols=1, vgap=8, hgap=8)
        SheetSizer = wx.BoxSizer(wx.HORIZONTAL)

        # Prepare some reusable arguments for calling sizer.Add():
        expandOption = dict(flag=wx.EXPAND)
        noOptions = dict()
        emptySpace = ((0, 0), noOptions)
    
        # Add the controls to the sizers:
        for control, options in \
                [(self.nameLabel, noOptions),
                 (self.nameTextCtrl, expandOption),
                 (self.referrerLabel, noOptions),
                 (self.referrerComboBox, expandOption),
                  emptySpace,
                 (self.insuranceCheckBox, noOptions),
                  emptySpace,
                 (self.colorRadioBox, noOptions),
                  emptySpace, 
                 (self.saveButton, dict(flag=wx.ALIGN_CENTER))]:
            gridSizer.Add(control, **options)

        for control, options in \
                [(self.TransformButton, noOptions),
                (self.ClearButton, noOptions),
                (self.IsiButton, noOptions)]:
            sizerButton.Add(control, **options)

        for control, options in \
                [(self.CSSourceLabel, noOptions),
                (self.CSSourceComboBox, expandOption),
                (self.CSDestLabel, noOptions),
                (self.CSDestComboBox, dict(border=10, flag=wx.BOTTOM))]:
            sizerPilihan.Add(control, **options)

        for control, options in \
                [(self.jumlahLabel, dict(flag= wx.ALIGN_CENTRE)),
                 (self.jumlahTextCtrl, dict(border=35, flag=wx.LEFT | wx.ALIGN_CENTRE)),
                 (self.terapkanButton, dict(border=35, flag=wx.LEFT | wx.ALIGN_CENTRE))
                 ]:
            sizerJmlTitik.Add(control, **options)

        for control, options in \
                [(self.CSSourceLabelGrid, dict(border=140, flag=wx.LEFT | wx.EXPAND)),
                 (self.GridGCS, dict(border=5, flag=wx.ALL))]:
            SheetSizerSource.Add(control, **options)

        for control, options in \
                [(self.CSDestLabelGrid, dict(border=70, flag=wx.LEFT | wx.EXPAND)),
                 (self.GridPCS, dict(border=5, flag=wx.ALL))]:
            SheetSizerDest.Add(control, **options)

        boxPilihan.Add(sizerPilihan)
        boxJmlTitik.Add(sizerJmlTitik)

        for control, options in \
                [(boxPilihan, noOptions),
                 (boxJmlTitik, expandOption),
                 (sizerButton, dict(border=15, flag=wx.TOP))]:
            sizerMenuKiri.Add(control, **options)

        for control, options in \
                [(SheetSizerSource, dict(border=5, flag=wx.ALL | wx.EXPAND)),
                 (SheetSizerDest, dict(border=5, flag=wx.ALL | wx.EXPAND))]:
            SheetSizer.Add(control, **options)

        for control, options in \
                [(sizerMenuKiri, dict(border=5, flag=wx.ALL)),
                (gridSizer, dict(border=5, flag=wx.ALL)),
                 (SheetSizer, dict(border=5, flag=wx.ALL|wx.EXPAND))]:
            boxSizer.Add(control, **options)

            boxSizer.Hide(gridSizer)

        self.SetSizerAndFit(boxSizer)

    def GetCoordCentralValue(self):
        return([self.GunakanDefault, self.DDDMS, self.LatCentral,self.LongCentral,self.HeightCentral])

    def SetCoordCentralValue(self, GunakanDefault, DDDMS, LatCentral, LongCentral, HeightCentral):
        self.GunakanDefault = GunakanDefault
        self.DDDMS = DDDMS
        self.LatCentral = LatCentral
        self.LongCentral = LongCentral
        self.HeightCentral = HeightCentral

class OptionsDialog(wx.Dialog):
    def __init__(self, parent, title): 
        super(OptionsDialog, self).__init__(parent, title = title) 

        self.parent_frame = parent
        self.KoordinatSentral = self.parent_frame.GetCoordCentralValue()
                
        #definisi array
        self.degrees = ['dd.dddd', 'dd mm ss.ssss']

        #definisi sumber
        self.defaultCheckBox = wx.CheckBox(self, label="Gunakan nilai default")
        self.defaultCheckBox.SetValue(1)
        self.degreesRadioBox = wx.RadioBox(self, choices=self.degrees, majorDimension=1, style=wx.RA_SPECIFY_ROWS | wx.TE_CENTRE, size=(0, -1))
        self.degreesRadioBox.Disable()
        self.degreesRadioBox.SetSelection(0)
        self.LatitudeLabelSourceDD = wx.StaticText(self, label="Lintang: ")
        self.LatitudeLabelSourceDMS = wx.StaticText(self, label="Lintang: ")
        self.LatitudeTextCtrlSourceDD = wx.TextCtrl(self, value="", style=wx.TE_READONLY, size=(140, -1))
        self.LatitudeTextCtrlSourceD = wx.TextCtrl(self, value="", style=wx.TE_READONLY | wx.TE_CENTRE, size=(40, -1))
        wx.TextCtrl.SetMaxLength(self.LatitudeTextCtrlSourceD,4)
        self.LatitudeTextCtrlSourceM = wx.TextCtrl(self, value="", style=wx.TE_READONLY | wx.TE_CENTRE, size=(40, -1))
        wx.TextCtrl.SetMaxLength(self.LatitudeTextCtrlSourceM,2)
        self.LatitudeTextCtrlSourceS = wx.TextCtrl(self, value="", style=wx.TE_READONLY | wx.TE_CENTRE, size=(40, -1))
        wx.TextCtrl.SetMaxLength(self.LatitudeTextCtrlSourceS,5)
        self.LatitudeNSDD = wx.TextCtrl(self, value="Selatan", style=wx.TE_READONLY | wx.TE_CENTRE, size=(50, -1))
        self.LatitudeNSDMS = wx.TextCtrl(self, value="Selatan", style=wx.TE_READONLY | wx.TE_CENTRE, size=(50, -1))
        self.LongitudelabelSourceDD = wx.StaticText(self, label="Bujur: ")
        self.LongitudelabelSourceDMS = wx.StaticText(self, label="Bujur: ")
        self.LongitudeTextCtrlSourceDD = wx.TextCtrl(self, value="", size=(140, -1))
        self.LongitudeTextCtrlSourceD = wx.TextCtrl(self, value="", style=wx.TE_READONLY | wx.TE_CENTRE, size=(40, -1))
        wx.TextCtrl.SetMaxLength(self.LongitudeTextCtrlSourceD,4)
        self.LongitudeTextCtrlSourceM = wx.TextCtrl(self, value="", style=wx.TE_READONLY | wx.TE_CENTRE, size=(40, -1))
        wx.TextCtrl.SetMaxLength(self.LongitudeTextCtrlSourceM,2)
        self.LongitudeTextCtrlSourceS = wx.TextCtrl(self, value="", style=wx.TE_READONLY | wx.TE_CENTRE, size=(40, -1))
        wx.TextCtrl.SetMaxLength(self.LongitudeTextCtrlSourceS,5)
        self.LongitudeWEDD = wx.TextCtrl(self, value="Timur", style=wx.TE_READONLY | wx.TE_CENTRE, size=(50, -1))
        self.LongitudeWEDMS = wx.TextCtrl(self, value="Timur", style=wx.TE_READONLY | wx.TE_CENTRE, size=(50, -1))
        self.HeightLabelSourceDD = wx.StaticText(self, label="Tinggi: ")
        self.HeightLabelSourceDMS = wx.StaticText(self, label="Tinggi:   ")
        self.HeightTextCtrlSourceDD = wx.TextCtrl(self, value="", style=wx.TE_READONLY, size=(140, -1))
        self.HeightTextCtrlSourceDMS = wx.TextCtrl(self, value="", style=wx.TE_READONLY, size=(140, -1))
        self.dummy = wx.StaticText(self, label="")

        #definisi button 
        self.button_ok = wx.Button(self, wx.ID_OK, label='&Oke')
        self.button_apply = wx.Button(self, wx.APPLY, label='&Terapkan')
        self.button_cancel = wx.Button(self, wx.ID_CANCEL, label='&Batal')

        #bind button              
        self.button_ok.Bind(wx.EVT_BUTTON, self.okEvent)
        self.button_apply.Bind(wx.EVT_BUTTON, self.applyEvent)
        self.button_cancel.Bind(wx.EVT_BUTTON, self.cancel_button)
        self.degreesRadioBox.Bind(wx.EVT_RADIOBOX, self.ChangeDDMS)
        self.defaultCheckBox.Bind(wx.EVT_CHECKBOX, self.CheckDefaultCentang)
        self.LatitudeTextCtrlSourceDD.Bind(wx.EVT_TEXT, self.checkNSDD)
        self.LongitudeTextCtrlSourceDD.Bind(wx.EVT_TEXT, self.checkWEDD)
        self.LatitudeTextCtrlSourceD.Bind(wx.EVT_TEXT, self.checkNSDMS)
        self.LongitudeTextCtrlSourceD.Bind(wx.EVT_TEXT, self.checkWEDMS)

        #definisi layout
        #self.panel = wx.Panel(self)
        self.vbox = wx.BoxSizer(wx.VERTICAL)
        self.gridSizerV = wx.FlexGridSizer(rows=2, cols=1, vgap=8, hgap=8)

        #self.judul = wx.StaticText('Koordinat Meridian Sentral TM Sementara:')
        self.FontJudul = wx.SystemSettings.GetFont(1)
        self.FontJudul.MakeBold()
        self.FontJudul.SetPointSize(10)
        self.labeler1 = wx.StaticBox(self, -1, 'Koordinat Meridian Sentral TM Sementara:')
        self.labeler1.SetFont(self.FontJudul)
        self.boxStatic1 = wx.StaticBoxSizer(self.labeler1,wx.VERTICAL)
        self.sizerMenuKiri = wx.FlexGridSizer(rows=3, cols=1, vgap=8, hgap=8)

        self.sizerMenuKiria = wx.BoxSizer(wx.HORIZONTAL)
        self.sizerMenuKirib = wx.FlexGridSizer(rows=2, cols=1, vgap=8, hgap=8)
        self.sizerMenuKiribi = wx.FlexGridSizer(rows=3, cols=3, vgap=8, hgap=8)
        self.sizerMenuKiribii = wx.FlexGridSizer(rows=2, cols=1, vgap=8, hgap=8)
        self.sizerMenuKiribiia = wx.FlexGridSizer(rows=2, cols=5, vgap=8, hgap=8)
        self.sizerMenuKiribiib = wx.FlexGridSizer(rows=1, cols=2, vgap=8, hgap=8)
        self.sizerMenuKiric = wx.BoxSizer(wx.HORIZONTAL)
        
        self.gridSizer2 = wx.FlexGridSizer(rows=1, cols=3, vgap=8, hgap=8)

        # Prepare some reusable arguments for calling sizer.Add():
        radioExpand = dict(flag=wx.EXPAND|wx.LEFT|wx.RIGHT|wx.TOP|wx.ALIGN_CENTER , border=0)
        expandOption = dict(flag=wx.EXPAND)
        textWrap = dict(flag=wx.SHRINK)
        noOptions = dict()
        emptySpace = ((0, 0), noOptions)

        self.vbox.Add(self.gridSizerV, border=20, flag=wx.ALL)
        self.boxStatic1.Add(self.sizerMenuKiri)

        for control, options in \
                [(self.boxStatic1, dict(border=5, flag=wx.ALL)),
                 (self.gridSizer2, dict(border=5, flag=wx.ALL))]:
            self.gridSizerV.Add(control, **options)

        for control, options in \
                [(self.sizerMenuKiria, noOptions),
                 (self.sizerMenuKirib, noOptions),
                 (self.sizerMenuKiric, noOptions)]:
            self.sizerMenuKiri.Add(control, **options)

        for control, options in \
                [(self.degreesRadioBox, dict(border=20, flag=wx.EXPAND|wx.LEFT))]:
            self.sizerMenuKiria.Add(control, **options)

        for control, options in \
                [(self.sizerMenuKiribi, expandOption),
                 (self.sizerMenuKiribii, expandOption)]:
            self.sizerMenuKirib.Add(control, **options)

        for control, options in \
                [(self.LatitudeLabelSourceDD, noOptions),
                 (self.LatitudeTextCtrlSourceDD, expandOption),
                 (self.LatitudeNSDD, textWrap),
                 (self.LongitudelabelSourceDD, noOptions),
                 (self.LongitudeTextCtrlSourceDD, expandOption),
                 (self.LongitudeWEDD, textWrap),
                 (self.HeightLabelSourceDD, noOptions),
                 (self.HeightTextCtrlSourceDD, expandOption),
                 emptySpace]:
            self.sizerMenuKiribi.Add(control, **options)

        for control, options in \
                [(self.sizerMenuKiribiia, expandOption),
                 (self.sizerMenuKiribiib, expandOption)]:
            self.sizerMenuKiribii.Add(control, **options)

        for control, options in \
                [(self.LatitudeLabelSourceDMS, noOptions),
                 (self.LatitudeTextCtrlSourceD, noOptions),
                 (self.LatitudeTextCtrlSourceM, noOptions),
                 (self.LatitudeTextCtrlSourceS, noOptions),
                 (self.LatitudeNSDMS, textWrap),
                 (self.LongitudelabelSourceDMS, noOptions),
                 (self.LongitudeTextCtrlSourceD, noOptions),
                 (self.LongitudeTextCtrlSourceM, noOptions),
                 (self.LongitudeTextCtrlSourceS, noOptions),
                 (self.LongitudeWEDMS, textWrap)]:
            self.sizerMenuKiribiia.Add(control, **options)

        for control, options in \
                [(self.HeightLabelSourceDMS, noOptions),
                 (self.HeightTextCtrlSourceDMS, expandOption)]:
            self.sizerMenuKiribiib.Add(control, **options)

        self.sizerMenuKirib.Hide(self.sizerMenuKiribii)

        for control, options in \
                [(self.dummy, dict(border=70, flag=wx.LEFT)),
                (self.defaultCheckBox, dict(border=15, flag=wx.EXPAND|wx.TOP|wx.BOTTOM))]:
            self.sizerMenuKiric.Add(control, **options)

        for control, options in \
                [(self.button_ok, noOptions),
                (self.button_apply, noOptions),
                (self.button_cancel, noOptions)]:
            self.gridSizer2.Add(control, **options)        

        #run script
        self.SetSizerAndFit(self.vbox)
        self.CheckSimpan()

    def ChangeDDMS(self, event):
        self.checkLayout()
        #self.clearAllTextSrc()

    def CheckSimpan(self):
        if not self.KoordinatSentral[0]: #pilihan default no
            self.defaultCheckBox.SetValue(0)
            self.setIsi(self.KoordinatSentral[2], self.KoordinatSentral[3], self.KoordinatSentral[4])
        else: #pilihan default yes
            self.defaultCheckBox.SetValue(1)
            self.setIsi(-6.89092328888889, 107.61234715277800, 789.2737)
        
        if self.KoordinatSentral[1] == 0: #pilihan DD
            self.degreesRadioBox.SetSelection(0)
            self.checkLayout()
        else: #pilihan DMS
            self.degreesRadioBox.SetSelection(1)
            self.checkLayout()

        self.CheckDefaultNoEvt()

    def CheckDefaultCentang(self, event):
        self.CheckDefaultNoEvt()
        self.setIsi(-6.89092328888889, 107.61234715277800, 789.2737)

    def CheckDefaultNoEvt(self):
        if not self.defaultCheckBox.GetValue():
            self.degreesRadioBox.Enable()
            self.LatitudeTextCtrlSourceDD.SetEditable(1)
            self.LongitudeTextCtrlSourceDD.SetEditable(1)
            self.HeightTextCtrlSourceDD.SetEditable(1)
            self.LatitudeTextCtrlSourceD.SetEditable(1)
            self.LatitudeTextCtrlSourceM.SetEditable(1)
            self.LatitudeTextCtrlSourceS.SetEditable(1)
            self.LongitudeTextCtrlSourceD.SetEditable(1)
            self.LongitudeTextCtrlSourceM.SetEditable(1)
            self.LongitudeTextCtrlSourceS.SetEditable(1)
            self.HeightTextCtrlSourceDMS.SetEditable(1)
            self.LatitudeTextCtrlSourceDD.SetBackgroundColour((255,255,255))
            self.LongitudeTextCtrlSourceDD.SetBackgroundColour((255,255,255))
            self.HeightTextCtrlSourceDD.SetBackgroundColour((255,255,255))
            self.LatitudeTextCtrlSourceD.SetBackgroundColour((255,255,255))
            self.LatitudeTextCtrlSourceM.SetBackgroundColour((255,255,255))
            self.LatitudeTextCtrlSourceS.SetBackgroundColour((255,255,255))
            self.LongitudeTextCtrlSourceD.SetBackgroundColour((255,255,255))
            self.LongitudeTextCtrlSourceM.SetBackgroundColour((255,255,255))
            self.LongitudeTextCtrlSourceS.SetBackgroundColour((255,255,255))
            self.HeightTextCtrlSourceDMS.SetBackgroundColour((255,255,255))
        else:
            self.degreesRadioBox.Disable()
            self.LatitudeTextCtrlSourceDD.SetEditable(0)
            self.LongitudeTextCtrlSourceDD.SetEditable(0)
            self.HeightTextCtrlSourceDD.SetEditable(0)
            self.LatitudeTextCtrlSourceD.SetEditable(0)
            self.LatitudeTextCtrlSourceM.SetEditable(0)
            self.LatitudeTextCtrlSourceS.SetEditable(0)
            self.LongitudeTextCtrlSourceD.SetEditable(0)
            self.LongitudeTextCtrlSourceM.SetEditable(0)
            self.LongitudeTextCtrlSourceS.SetEditable(0)
            self.HeightTextCtrlSourceDMS.SetEditable(0)
            self.disabled_color=(210,210,210)
            self.LatitudeTextCtrlSourceDD.SetBackgroundColour(self.disabled_color)
            self.LongitudeTextCtrlSourceDD.SetBackgroundColour(self.disabled_color)
            self.HeightTextCtrlSourceDD.SetBackgroundColour(self.disabled_color)
            self.LatitudeTextCtrlSourceD.SetBackgroundColour(self.disabled_color)
            self.LatitudeTextCtrlSourceM.SetBackgroundColour(self.disabled_color)
            self.LatitudeTextCtrlSourceS.SetBackgroundColour(self.disabled_color)
            self.LongitudeTextCtrlSourceD.SetBackgroundColour(self.disabled_color)
            self.LongitudeTextCtrlSourceM.SetBackgroundColour(self.disabled_color)
            self.LongitudeTextCtrlSourceS.SetBackgroundColour(self.disabled_color)
            self.HeightTextCtrlSourceDMS.SetBackgroundColour(self.disabled_color)

    def setIsi(self, Lat, Long, Height):
        LatDMS = DD2DMS(Lat)
        LongDMS = DD2DMS(Long)
        self.LatitudeTextCtrlSourceDD.SetValue(str(Lat))
        self.LongitudeTextCtrlSourceDD.SetValue(str(Long))
        self.HeightTextCtrlSourceDD.SetValue(str(Height))
        self.LatitudeTextCtrlSourceD.SetValue(str(LatDMS[0]))
        self.LatitudeTextCtrlSourceM.SetValue(str(LatDMS[1]))
        self.LatitudeTextCtrlSourceS.SetValue(str(LatDMS[2]))
        self.LongitudeTextCtrlSourceD.SetValue(str(LongDMS[0]))
        self.LongitudeTextCtrlSourceM.SetValue(str(LongDMS[1]))
        self.LongitudeTextCtrlSourceS.SetValue(str(LongDMS[2]))
        self.HeightTextCtrlSourceDMS.SetValue(str(Height))
        self.__changeNSDD(str(self.LatitudeTextCtrlSourceDD.GetValue()))
        self.__changeWEDD(str(self.LongitudeTextCtrlSourceDD.GetValue()))
        self.__changeNSDMS(str(self.LatitudeTextCtrlSourceD.GetValue()))
        self.__changeWEDMS(str(self.LongitudeTextCtrlSourceD.GetValue()))

    def okEvent(self, event):
        if self.IsModal():
            self.EndModal(event.EventObject.Id)
            self.applyValue()
        else:
            self.applyValue()
            self.Close()


    def applyEvent(self, event):
        self.applyValue()

    def applyValue(self):
        if self.degreesRadioBox.GetSelection() == 0:
            LatitudeCentral = math.fabs(float(self.LatitudeTextCtrlSourceDD.GetValue()))
            LongitudeCentral = math.fabs(float(self.LongitudeTextCtrlSourceDD.GetValue()))
            HeightCentral = float(self.HeightTextCtrlSourceDD.GetValue())
            if self.LatitudeNSDD.GetValue() == 'Selatan':
                LatitudeCentral=0-LatitudeCentral
            if self.LongitudeWEDD.GetValue() == 'Barat':
                LongitudeCentral=360-LongitudeCentral
        else:
            LatitudeCentral = math.fabs(float(self.LatitudeTextCtrlSourceD.GetValue())) + math.fabs(float(self.LatitudeTextCtrlSourceM.GetValue())/60) + math.fabs(float(self.LatitudeTextCtrlSourceS.GetValue())/3600)
            LongitudeCentral = math.fabs(float(self.LongitudeTextCtrlSourceD.GetValue())) + math.fabs(float(self.LongitudeTextCtrlSourceM.GetValue())/60) + math.fabs(float(self.LongitudeTextCtrlSourceS.GetValue())/3600)
            HeightCentral = float(self.HeightTextCtrlSourceDMS.GetValue())
            if self.LatitudeNSDMS.GetValue() == 'Selatan':
                LatitudeCentral=0-LatitudeCentral
            if self.LongitudeWEDMS.GetValue() == 'Barat':
                LongitudeCentral=360-LongitudeCentral

        self.parent_frame.SetCoordCentralValue(self.defaultCheckBox.GetValue(),self.degreesRadioBox.GetSelection(),LatitudeCentral,LongitudeCentral,HeightCentral)

    def clearAllTextSrc(self):
        self.LatitudeTextCtrlSourceDD.Clear()
        self.LatitudeTextCtrlSourceD.Clear() 
        self.LatitudeTextCtrlSourceM.Clear()  
        self.LatitudeTextCtrlSourceS.Clear() 
        self.LongitudeTextCtrlSourceDD.Clear() 
        self.LongitudeTextCtrlSourceD.Clear()  
        self.LongitudeTextCtrlSourceM.Clear()  
        self.LongitudeTextCtrlSourceS.Clear() 
        self.HeightTextCtrlSourceDD.Clear() 
        self.HeightTextCtrlSourceDMS.Clear()  

    def checkLayout(self):
        #check layout DD/DMS
        if self.degreesRadioBox.GetSelection() == 0:
             self.sizerMenuKirib.Show(self.sizerMenuKiribi)
             self.sizerMenuKirib.Hide(self.sizerMenuKiribii)           
        else:
             self.sizerMenuKirib.Hide(self.sizerMenuKiribi)
             self.sizerMenuKirib.Show(self.sizerMenuKiribii)           
        self.Layout()

    def checkNSDD(self, event):
        self.__changeNSDD('%s'%event.GetString())
        event.Skip()

    def checkNSDMS(self, event):
        self.__changeNSDMS('%s'%event.GetString())
        event.Skip()

    def checkWEDD(self, event):
        self.__changeWEDD('%s'%event.GetString())
        event.Skip()

    def checkWEDMS(self, event):
        self.__changeWEDMS('%s'%event.GetString())
        event.Skip()

    def __changeNSDD(self, stringZ):
        if len(stringZ) > 0:
            if stringZ[0] == "-":
                self.LatitudeNSDD.ChangeValue('Selatan')
            else:
                self.LatitudeNSDD.ChangeValue('Utara')

    def __changeWEDD(self, stringZ):
        if len(stringZ) > 0:
            if stringZ[0] == "-":
                self.LongitudeWEDD.ChangeValue('Barat')
            else:
                self.LongitudeWEDD.ChangeValue('Timur')

    def __changeNSDMS(self, stringZ):
        if len(stringZ) > 0:
            if stringZ[0] == "-":
                self.LatitudeNSDMS.ChangeValue('Selatan')
            else:
                self.LatitudeNSDMS.ChangeValue('Utara')

    def __changeWEDMS(self, stringZ):
        if len(stringZ) > 0:
            if stringZ[0] == "-":
                self.LongitudeWEDMS.ChangeValue('Barat')
            else:
                self.LongitudeWEDMS.ChangeValue('Timur')

    def cancel_button(self, event):
        if self.IsModal():
            self.EndModal(event.EventObject.Id)
        else:
            self.Close()

class FrameWithForms(wx.Frame):
    def __init__(self, *args, **kwargs):
        super(FrameWithForms, self).__init__(*args, **kwargs)
        notebook = wx.Notebook(self)
        #self.form1 = FormWithSizer1(notebook)
        self.form2 = FormWithSizer2(notebook)
        #notebook.AddPage(self.form1, '&Koordinat Tunggal')
        notebook.AddPage(self.form2, '&Multi Koordinat ')

        self.CreateStatusBar() # A Statusbar in the bottom of the window

        # Setting up the menu.
        filemenu1= wx.Menu()
        keluar = wx.MenuItem(filemenu1,wx.ID_EXIT,"&Keluar\tCtrl+K","Keluar dari Aplikasi")
        keluar.SetBitmap(wx.Bitmap('img/exit.png'))
        menuExit = filemenu1.Append(keluar)        

        filemenu2= wx.Menu()
        opsi = wx.MenuItem(filemenu2,wx.ID_HELP,"&Opsi\tCtrl+O","Opsi Processing")
        opsi.SetBitmap(wx.Bitmap('img/opsi.png'))
        menuOptions= filemenu2.Append(opsi)
        
        filemenu3= wx.Menu()
        tentang = wx.MenuItem(filemenu3,wx.ID_ABOUT, "&Tentang\tCtrl+T","Tentang Aplikasi")
        tentang.SetBitmap(wx.Bitmap('img/about.png'))
        menuAbout= filemenu3.Append(tentang)        

        # Creating the menubar.
        menuBar = wx.MenuBar()
        menuBar.Append(filemenu1,"Ber&kas") # Adding the "filemenu1" to the MenuBar
        menuBar.Append(filemenu2,"&Alat") # Adding the "filemenu2" to the MenuBar
        menuBar.Append(filemenu3,"&Bantuan") # Adding the "filemenu3" to the MenuBar
        self.SetMenuBar(menuBar)  # Adding the MenuBar to the Frame content.

        # Events
        self.Bind(wx.EVT_MENU, self.OnExit, menuExit)
        self.Bind(wx.EVT_MENU, self.OnOptions, menuOptions)
        self.Bind(wx.EVT_MENU, self.OnAbout, menuAbout)
       
        # We just set the frame to the right size manually. This is feasible
        # for the frame since the frame contains just one component. If the
        # frame had contained more than one component, we would use sizers
        # of course, as demonstrated in the FormWithSizer class above.
        self.SetClientSize(notebook.GetBestSize())
        #self.SetClientSize(notebook.SetSize(500, -1))

    def OnAbout(self,e):
        # Create a message dialog box
        dlg = wx.MessageDialog(self, " © Copyleft 2019 \n Perangkat Lunak Bad Computation \n dibuat oleh Kelompok Keilmuan Geodesi ITB", "About", wx.OK)
        dlg.ShowModal() # Shows it
        dlg.Destroy() # finally destroy it when finished.

    def OnOptions(self,e):
        # Create a message dialog box
        #dlg = wx.MessageDialog(self, "Nanti disini dikasih opsi2", "Options", wx.OK)
        #dlg = MyDialog(None, title='Opsi')
        self.dlg = OptionsDialog(self.form2, title='Opsi')
        self.dlg.ShowModal() # Shows it
        self.dlg.Destroy() # finally destroy it when finished.
        #self.options_frame = OptionsDialog(self,)
        #self.options_frame.Show()

    def OnExit(self,e):
        self.Close(True)  # Close the frame.

class MyGrid(wx.grid.Grid):
    def __init__(self, parent):
        wx.grid.Grid.__init__(self, parent, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, 0)
        self.Bind(wx.EVT_KEY_DOWN, self.on_key)
        self.Bind(wx.grid.EVT_GRID_CELL_CHANGING, self.on_change)
        self.Bind(wx.grid.EVT_GRID_LABEL_RIGHT_CLICK, self.on_label_right_click)
        self.Bind(wx.grid.EVT_GRID_CELL_RIGHT_CLICK, self.on_cell_right_click)
        self.selected_rows = []
        self.selected_cols = []
        self.history = []

    def get_col_headers(self):
        return [self.GetColLabelValue(col) for col in range(self.GetNumberCols())]

    def get_table(self):
        for row in range(self.GetNumberRows()):
            result = {}
            for col, header in enumerate(self.get_col_headers()):
                result[header] = self.GetCellValue(row, col)
            yield result

    def add_rows(self, event):
        for row in self.selected_rows:
            self.InsertRows(row)
        self.add_history({"type": "add_rows", "rows": self.selected_rows})

    def delete_rows(self, event):
        self.cut(event)
        rows = []
        for row in reversed(self.selected_rows):
            rows.append((
                row,
                {  # More attributes can be added
                    "label": self.GetRowLabelValue(row),
                    "size": self.GetRowSize(row)
                }
            ))
            self.DeleteRows(row)
        self.add_history({"type": "delete_rows", "rows": rows})

    def add_cols(self, event):
        for col in self.selected_cols:
            self.InsertCols(col)
        self.add_history({"type": "add_cols", "cols": self.selected_cols})

    def delete_cols(self, event):
        self.delete(event)
        cols = []
        for col in reversed(self.selected_cols):
            cols.append((
                col,
                {  # More attributes can be added
                    "label": self.GetColLabelValue(col),
                    "size": self.GetColSize(col)
                }
            ))
            self.DeleteCols(col)
        self.add_history({"type": "delete_cols", "cols": cols})

    def on_cell_right_click(self, event):
        menus = [(wx.NewId(), "Cut", self.cut),
                 (wx.NewId(), "Copy", self.copy),
                 (wx.NewId(), "Paste", self.paste)]
        popup_menu = wx.Menu()
        for menu in menus:
            if menu is None:
                popup_menu.AppendSeparator()
                continue
            popup_menu.Append(menu[0], menu[1])
            self.Bind(wx.EVT_MENU, menu[2], id=menu[0])

        self.PopupMenu(popup_menu, event.GetPosition())
        popup_menu.Destroy()
        return

    def on_label_right_click(self, event):
        menus = [(wx.NewId(), "Cut", self.cut),
                 (wx.NewId(), "Copy", self.copy),
                 (wx.NewId(), "Paste", self.paste),
                 None]

        # Select if right clicked row or column is not in selection
        if event.GetRow() > -1:
            if not self.IsInSelection(row=event.GetRow(), col=1):
                self.SelectRow(event.GetRow())
            self.selected_rows = self.GetSelectedRows()
            menus += [(wx.NewId(), "Add row", self.add_rows)]
            menus += [(wx.NewId(), "Delete row", self.delete_rows)]
        elif event.GetCol() > -1:
            if not self.IsInSelection(row=1, col=event.GetCol()):
                self.SelectCol(event.GetCol())
            self.selected_cols = self.GetSelectedCols()
            menus += [(wx.NewId(), "Add column", self.add_cols)]
            menus += [(wx.NewId(), "Delete column", self.delete_cols)]
        else:
            return

        popup_menu = wx.Menu()
        for menu in menus:
            if menu is None:
                popup_menu.AppendSeparator()
                continue
            popup_menu.Append(menu[0], menu[1])
            self.Bind(wx.EVT_MENU, menu[2], id=menu[0])

        self.PopupMenu(popup_menu, event.GetPosition())
        popup_menu.Destroy()
        return

    def on_change(self, event):
        cell = event.GetEventObject()
        row = cell.GetGridCursorRow()
        col = cell.GetGridCursorCol()
        attribute = {"value": self.GetCellValue(row, col)}
        self.add_history({"type": "change", "cells": [(row, col, attribute)]})

    def add_history(self, change):
        self.history.append(change)

    def undo(self):
        if not len(self.history):
            return

        action = self.history.pop()
        if action["type"] == "change" or action["type"] == "delete":
            for row, col, attribute in action["cells"]:
                self.SetCellValue(row, col, attribute["value"])
                if action["type"] == "delete":
                    self.SetCellAlignment(row, col, *attribute["alignment"])  # *attribute["alignment"] > horiz, vert

        elif action["type"] == "delete_rows":
            for row, attribute in reversed(action["rows"]):
                self.InsertRows(row)
                self.SetRowLabelValue(row, attribute["label"])
                self.SetRowSize(row, attribute["size"])

        elif action["type"] == "delete_cols":
            for col, attribute in reversed(action["cols"]):
                self.InsertCols(col)
                self.SetColLabelValue(col, attribute["label"])
                self.SetColSize(col, attribute["size"])

        elif action["type"] == "add_rows":
            for row in reversed(action["rows"]):
                self.DeleteRows(row)

        elif action["type"] == "add_cols":
            for col in reversed(action["cols"]):
                self.DeleteCols(col)
        else:
            return

    def on_key(self, event):
        """
        Handles all key events.
        """
        # print(event.GetKeyCode())
        # Ctrl+C or Ctrl+Insert
        if event.ControlDown() and event.GetKeyCode() in [67, 322]:
            self.copy(event)

        # Ctrl+V
        elif event.ControlDown() and event.GetKeyCode() == 86:
            self.paste(event)

        # DEL
        elif event.GetKeyCode() == 127:
            self.delete(event)

        # Ctrl+A
        elif event.ControlDown() and event.GetKeyCode() == 65:
            self.SelectAll()

        # Ctrl+Z
        elif event.ControlDown() and event.GetKeyCode() == 90:
            self.undo()

        # Ctrl+X
        elif event.ControlDown() and event.GetKeyCode() == 88:
            # Call delete method
            self.cut(event)

        # Ctrl+V or Shift + Insert
        elif (event.ControlDown() and event.GetKeyCode() == 67) \
                or (event.ShiftDown() and event.GetKeyCode() == 322):
            self.paste(event)

        else:
            event.Skip()

    def get_selection(self):
        """
        Returns selected range's start_row, start_col, end_row, end_col
        If there is no selection, returns selected cell's start_row=end_row, start_col=end_col
        """
        if not len(self.GetSelectionBlockTopLeft()):
            selected_columns = self.GetSelectedCols()
            selected_rows = self.GetSelectedRows()
            if selected_columns:
                start_col = selected_columns[0]
                end_col = selected_columns[-1]
                start_row = 0
                end_row = self.GetNumberRows() - 1
            elif selected_rows:
                start_row = selected_rows[0]
                end_row = selected_rows[-1]
                start_col = 0
                end_col = self.GetNumberCols() - 1
            else:
                start_row = end_row = self.GetGridCursorRow()
                start_col = end_col = self.GetGridCursorCol()
        elif len(self.GetSelectionBlockTopLeft()) > 1:
            wx.MessageBox("Multiple selections are not supported", "Warning")
            return []
        else:
            start_row, start_col = self.GetSelectionBlockTopLeft()[0]
            end_row, end_col = self.GetSelectionBlockBottomRight()[0]

        return [start_row, start_col, end_row, end_col]

    def get_selected_cells(self):
        # returns a list of selected cells
        selection = self.get_selection()
        if not selection:
            return

        start_row, start_col, end_row, end_col = selection
        for row in range(start_row, end_row + 1):
            for col in range(start_col, end_col + 1):
                yield [row, col]

    def copy(self, event):
        """
        Copies range of selected cells to clipboard.
        """

        selection = self.get_selection()
        if not selection:
            return []
        start_row, start_col, end_row, end_col = selection

        data = u''

        rows = range(start_row, end_row + 1)
        for row in rows:
            columns = range(start_col, end_col + 1)
            for idx, column in enumerate(columns, 1):
                if idx == len(columns):
                    # if we are at the last cell of the row, add new line instead
                    data += self.GetCellValue(row, column) + "\n"
                else:
                    data += self.GetCellValue(row, column) + "\t"

        text_data_object = wx.TextDataObject()
        text_data_object.SetText(data)

        if wx.TheClipboard.Open():
            wx.TheClipboard.SetData(text_data_object)
            wx.TheClipboard.Close()
        else:
            wx.MessageBox("Can't open the clipboard", "Warning")

    def paste(self, event):
        if not wx.TheClipboard.Open():
            wx.MessageBox("Can't open the clipboard", "Warning")
            return False

        clipboard = wx.TextDataObject()
        wx.TheClipboard.GetData(clipboard)
        wx.TheClipboard.Close()
        data = clipboard.GetText()
        if data[-1] == "\n":
            data = data[:-1]

        try:
            cells = self.get_selected_cells()
            cell = next(cells)
        except StopIteration:
            return False

        start_row = end_row = cell[0]
        start_col = end_col = cell[1]
        max_row = self.GetNumberRows()
        max_col = self.GetNumberCols()

        history = []
        out_of_range = False

        for row, line in enumerate(data.split("\n")):
            target_row = start_row + row
            if not (0 <= target_row < max_row):
                out_of_range = True
                break

            if target_row > end_row:
                end_row = target_row

            for col, value in enumerate(line.split("\t")):
                target_col = start_col + col
                if not (0 <= target_col < max_col):
                    out_of_range = True
                    break

                if target_col > end_col:
                    end_col = target_col

                # save previous value of the cell for undo
                history.append([target_row, target_col, {"value": self.GetCellValue(target_row, target_col)}])

                self.SetCellValue(target_row, target_col, value)

        self.SelectBlock(start_row, start_col, end_row, end_col)  # select pasted range
        if out_of_range:
            wx.MessageBox("Pasted data is out of Grid range", "Warning")

        self.add_history({"type": "change", "cells": history})

    def delete(self, event):
        cells = []
        for row, col in self.get_selected_cells():
            attributes = {
                "value": self.GetCellValue(row, col),
                "alignment": self.GetCellAlignment(row, col)
            }
            cells.append((row, col, attributes))
            self.SetCellValue(row, col, "")

        self.add_history({"type": "delete", "cells": cells})

    def cut(self, event):
        self.copy(event)
        self.delete(event)

if __name__ == '__main__':
    app = wx.App(0)
    frame = FrameWithForms(None, title='Bad Computation')
    frame.Show()
    app.MainLoop()