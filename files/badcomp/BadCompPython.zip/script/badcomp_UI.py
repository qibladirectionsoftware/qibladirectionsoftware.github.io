# -*- coding: utf-8 -*-

import wx
import math

################################## Core Engine ########################################
def DD2DMS(DD):
    if DD < 0:
        negatif = 1
    else:
        negatif = 0 

    DD = math.fabs(DD)

    D=int(math.floor(DD))
    M=int(math.floor((DD-D)*60))
    S=math.floor(((M-((DD-D)*60))*60)*1000)/1000

    if negatif:
        DMS=[-D,M,S]
    else:
        DMS=[D,M,S]
    return DMS

def geod2geos(lat,lon,height,a,e):

    phi=math.radians(lat)
    lamda=math.radians(lon)
    h=height

    N=a/math.sqrt(1-math.pow(e,2)*math.pow(math.sin(phi),2))

    X=(N+h)*math.cos(phi)*math.cos(lamda)
    Y=(N+h)*math.cos(phi)*math.sin(lamda)
    Z=(N*(1-math.pow(e,2))+h)*math.sin(phi)

    XYZ=[X,Y,Z]
    return XYZ

def geos2geod(X,Y,Z,a,e):

    lamda=math.atan2(Y,X)
    p=math.sqrt(math.pow(X,2)+math.pow(Y,2))

    h0=0
    phi0=math.atan(Z/(p*(1-math.pow(e,2))))
    N=a/math.sqrt(1-math.pow(e,2)*math.pow(math.sin(phi0),2))
    h=(p/math.cos(phi0))-N
    phi=math.atan(Z/(p*(1-(math.pow(e,2)*N/(N+h)))))
    while math.fabs(h-h0)>0.0000000001 and math.fabs(phi-phi0)>0.00000001:
        h0=h
        phi0=phi
        N=a/math.sqrt(1-math.pow(e,2)*math.pow(math.sin(phi),2))
        h=(p/math.cos(phi))-N
        phi=math.atan(Z/(p*(1-(math.pow(e,2)*N/(N+h)))))

    philamdaH=[math.degrees(phi),math.degrees(lamda),h]
    return philamdaH

def geod2TM(phi,lamda,lamda0,a,e):

    k0=1
    FalseE=0
    FalseN=0
    phi0=0

    phi=math.radians(phi)
    lamda=math.radians(lamda)
    lamda0=math.radians(lamda0)
    phi0=math.radians(phi0)

    b=a*math.sqrt(1-math.pow(e,2))
    e2=math.sqrt((math.pow(a,2)-math.pow(b,2))/math.pow(b,2))

    T=math.pow(math.tan(phi),2)   
    C=math.pow(e,2)*math.pow(math.cos(phi),2)/(1-math.pow(e,2))
    A=(lamda-lamda0)*math.cos(phi)
    N=a/math.sqrt(1-math.pow(e,2)*math.pow(math.sin(phi),2))
    M=a*((1-math.pow(e,2)/4-3*math.pow(e,4)/64-5*math.pow(e,6)/256)*phi-(3*math.pow(e,2)/8+3*math.pow(e,4)/32+45*math.pow(e,6)/1024)*math.sin(2*phi)+(15*math.pow(e,4)/256+45*math.pow(e,6)/1024)*math.sin(4*phi)-(35*math.pow(e,6)/3072)*math.sin(6*phi))
    M0=a*((1-math.pow(e,2)/4-3*math.pow(e,4)/64-5*math.pow(e,6)/256)*phi0-(3*math.pow(e,2)/8+3*math.pow(e,4)/32+45*math.pow(e,6)/1024)*math.sin(2*phi0)+(15*math.pow(e,4)/256+45*math.pow(e,6)/1024)*math.sin(4*phi0)-(35*math.pow(e,6)/3072)*math.sin(6*phi0))

    E=N*(A+(1-T+C)*math.pow(A,3)/6+(5-18*T+math.pow(T,2)+72*C-58*math.pow(e2,2))*math.pow(A,5)/120)
    N=M-M0+N*math.tan(phi)*(math.pow(A,2)/2+(5-T+9*C+4*math.pow(C,2))*math.pow(A,4)/24+(61-58*T+math.pow(T,2)+600*C-330*math.pow(e2,2))*math.pow(A,6)/720)

    x=FalseE+k0*E
    y=FalseN+k0*N
    xy=[x,y]

    return xy

def TM2geod(x,y,lamda0,a,e):

    k0=1;
    FalseE=0;
    FalseN=0;
    phi0=0;

    lamda0=math.radians(lamda0)
    phi0=math.radians(phi0)

    b=a*math.sqrt(1-math.pow(e,2))
    e2=math.sqrt((math.pow(a,2)-math.pow(b,2))/math.pow(b,2))
    e1=(1-math.sqrt(1-math.pow(e,2)))/(1+math.sqrt(1-math.pow(e,2)))

    M0=a*((1-math.pow(e,2)/4-3*math.pow(e,4)/64-5*math.pow(e,6)/256)*phi0-(3*math.pow(e,2)/8+3*math.pow(e,4)/32+45*math.pow(e,6)/1024)*math.sin(2*phi0)+(15*math.pow(e,4)/256+45*math.pow(e,6)/1024)*math.sin(4*phi0)-(35*math.pow(e,6)/3072)*math.sin(6*phi0))
    M1=M0+(y-FalseN)/k0
    u1=M1/(a*(1-math.pow(e,2)/4-3*math.pow(e,4)/64-5*math.pow(e,6)/256))
    phi1= u1+(3*e1/2-27*math.pow(e1,3)/32)*math.sin(2*u1)+(21*math.pow(e1,2)/16-55*math.pow(e1,4)/32)*math.sin(4*u1)+(151*math.pow(e1,3)/96)*math.sin(6*u1)+(1097*math.pow(e1,4)/512)*math.sin(8*u1)
    T1=math.pow(math.tan(phi1),2)

    C1=math.pow(e2,2)*math.pow(math.cos(phi1),2)
    N1=a/math.sqrt(1-math.pow(e,2)*math.pow(math.sin(phi1),2))
    D=(x-FalseE)/(N1*k0)

    rho1=a*(1-math.pow(e,2))/math.pow((1-math.pow(e,2)*math.pow(math.sin(phi1),2)),(3/2))
    phi=phi1-(N1*math.tan(phi1)/rho1)*(math.pow(D,2)/2-(5+3*T1+10*C1-4*math.pow(C1,2)-9*math.pow(e2,2))*math.pow(D,4)/24+(61+90*T1+298*C1+45*math.pow(T1,2)-252*math.pow(e2,2)-3*math.pow(C1,2)+8*math.pow(e2,2))*math.pow(D,6)/720)
    lamda=lamda0+(D-(1+2*T1+C1)*math.pow(D,3)/6+(5-2*C1+28*T1-3*math.pow(C1,2)+8*math.pow(e2,2)+24*math.pow(T1,2))*math.pow(D,5)/120)/math.cos(phi1)
    
    phi=math.degrees(phi)
    lamda=math.degrees(lamda)
    
    philamda=[phi,lamda]

    return philamda

def latlonh2sementara(lat,lon,H,lat0,lon0,h0):

    lat0=math.radians(lat0)

    #parameter
    a_wgs84 = 6378137
    e_wgs84 = 0.0818191908426215
    e_sementara = 0

    #geosentrik nasional
    xyz_nasional=geod2geos(lat,lon,H,a_wgs84,e_wgs84)

    lat=math.radians(lat)
    lon=math.radians(lon)

    #geosentrik sementara
    N0=a_wgs84/(math.sqrt(1-math.pow(e_wgs84,2)*math.pow(math.sin(lat0),2)))
    zll=(N0*(1-math.pow(e_wgs84,2)))*math.sin(lat0)
    if lat < 0: #selatan ekuator
        xyz_sementara = [xyz_nasional[0]-0,xyz_nasional[1]-0,xyz_nasional[2]-((math.fabs(N0*math.sin(lat0))-math.fabs(zll)))]
    else: #utara ekuator
        xyz_sementara = [xyz_nasional[0]+0,xyz_nasional[1]+0,xyz_nasional[2]+((math.fabs(N0*math.sin(lat0))-math.fabs(zll)))]

    #radius bola sementara
    r0=N0+h0

    #geodetik sementara
    latlonHS=geos2geod(xyz_sementara[0],xyz_sementara[1],xyz_sementara[2],r0,e_sementara)

    #TM sementara
    xy_sementara=geod2TM(latlonHS[0],latlonHS[1],lon0,r0,e_sementara)
    eastingSementara=xy_sementara[0]
    northingSementara=xy_sementara[1]

    #simpan nilai variabel
    transXYZ = [xyz_sementara[0]-xyz_nasional[0],xyz_sementara[1]-xyz_nasional[1],xyz_sementara[2]-xyz_nasional[2]]

    output=[eastingSementara,northingSementara]

    return output

def sementara2latlonh(eastingSementara,northingSementara,lat0,lon0,h0):

    lat0=math.radians(lat0)

    #parameter
    a_wgs84 = 6378137
    e_wgs84 = 0.0818191908426215

    N0=a_wgs84/(math.sqrt(1-math.pow(e_wgs84,2)*math.pow(math.sin(lat0),2)))
    zll=(N0*(1-math.pow(e_wgs84,2)))*math.sin(lat0)
    transZ=0-((math.fabs(N0*math.sin(lat0))-math.fabs(zll)))

    #radius bola sementara
    r0=N0+h0

    #geodetik sementara
    latlonH_sementara=TM2geod(eastingSementara,northingSementara,lon0,r0,0)

    #geosentrik sementara
    xyz_sementara=geod2geos(latlonH_sementara[0],latlonH_sementara[1],0,r0,0)

    #geosentrik nasional
    if northingSementara < 0: #selatan ekuator
        xyz_nasional = [xyz_sementara[0],xyz_sementara[1],xyz_sementara[2]-transZ]
    else: #utara ekuator
        xyz_nasional = [xyz_sementara[0],xyz_sementara[1],xyz_sementara[2]+transZ]

    #geodetik nasional
    latlonH=geos2geod(xyz_nasional[0],xyz_nasional[1],xyz_nasional[2],a_wgs84,e_wgs84)

    output=[latlonH[0],latlonH[1]]

    return output

################################## User Interface ########################################

class Form1(wx.Panel):
    ''' The Form class is a wx.Panel that creates a bunch of controls
        and handlers for callbacks. Doing the layout of the controls is 
        the responsibility of subclasses (by means of the doLayout()
        method). '''

    def __init__(self, *args, **kwargs):
        super(Form1, self).__init__(*args, **kwargs)
        self.coordSystem = ['GCS WGS 1984','TM Sementara SRGI 2013']
        self.degrees = ['dd.dddd', 'dd mm ss.ssss']
        self.createControls()
        self.bindEvents()
        self.doLayout()

        self.LatCentral = float("-6.89092328888889")
        self.LongCentral = float("107.61234715277800")
        self.HeightCentral = float("789.2737")

        self.GunakanDefault = True
        self.DDDMS = 0

    def createControls(self):

        #tombol di bawah dan disamping
        self.logger = wx.TextCtrl(self, style=wx.TE_MULTILINE|wx.TE_READONLY, size=(300, -1))        
        self.TransformButton = wx.Button(self, label="&Transformasi", size=(100, -1))
        self.TransformButton.SetBitmap(wx.Bitmap('img/cal.png'))
        self.SwapButton = wx.Button(self, label="T&ukar", size=(100, -1))
        self.SwapButton.SetBitmap(wx.Bitmap('img/swap.png'))
        self.ClearButton = wx.Button(self, label="&Hapus...", size=(100, -1))
        self.ClearButton.SetBitmap(wx.Bitmap('img/blank.png'))
        self.IsiButton = wx.Button(self, label="&Isi Contoh", size=(100, -1))
        self.IsiButton.SetBitmap(wx.Bitmap('img/pencil.png'))

        #GCS Sumber
        self.degreesRadioBox = wx.RadioBox(self, choices=self.degrees, majorDimension=1, style=wx.RA_SPECIFY_COLS)
        self.LatitudeLabelSourceDD = wx.StaticText(self, label="Lintang:                               ")
        self.LatitudeLabelSourceDMS = wx.StaticText(self, label="Lintang:                               ")
        self.LatitudeTextCtrlSourceDD = wx.TextCtrl(self, value="", size=(140, -1))
        self.LatitudeTextCtrlSourceD = wx.TextCtrl(self, value="", style=wx.TE_CENTRE, size=(40, -1))
        wx.TextCtrl.SetMaxLength(self.LatitudeTextCtrlSourceD,4)
        self.LatitudeTextCtrlSourceM = wx.TextCtrl(self, value="", style=wx.TE_CENTRE, size=(40, -1))
        wx.TextCtrl.SetMaxLength(self.LatitudeTextCtrlSourceM,2)
        self.LatitudeTextCtrlSourceS = wx.TextCtrl(self, value="", style=wx.TE_CENTRE, size=(40, -1))
        wx.TextCtrl.SetMaxLength(self.LatitudeTextCtrlSourceS,5)
        self.LatitudeNSDD = wx.TextCtrl(self, value="Utara", style=wx.TE_READONLY | wx.TE_CENTRE, size=(50, -1))
        self.LatitudeNSDMS = wx.TextCtrl(self, value="Utara", style=wx.TE_READONLY | wx.TE_CENTRE, size=(50, -1))
        self.LongitudelabelSourceDD = wx.StaticText(self, label="Bujur:                        ")
        self.LongitudelabelSourceDMS = wx.StaticText(self, label="Bujur:                        ")
        self.LongitudeTextCtrlSourceDD = wx.TextCtrl(self, value="", size=(140, -1))
        self.LongitudeTextCtrlSourceD = wx.TextCtrl(self, value="", style=wx.TE_CENTRE, size=(40, -1))
        wx.TextCtrl.SetMaxLength(self.LongitudeTextCtrlSourceD,4)
        self.LongitudeTextCtrlSourceM = wx.TextCtrl(self, value="", style=wx.TE_CENTRE, size=(40, -1))
        wx.TextCtrl.SetMaxLength(self.LongitudeTextCtrlSourceM,2)
        self.LongitudeTextCtrlSourceS = wx.TextCtrl(self, value="", style=wx.TE_CENTRE, size=(40, -1))
        wx.TextCtrl.SetMaxLength(self.LongitudeTextCtrlSourceS,5)
        self.LongitudeWEDD = wx.TextCtrl(self, value="Timur", style=wx.TE_READONLY | wx.TE_CENTRE, size=(50, -1))
        self.LongitudeWEDMS = wx.TextCtrl(self, value="Timur", style=wx.TE_READONLY | wx.TE_CENTRE, size=(50, -1))
        self.HeightLabelSourceDD = wx.StaticText(self, label="Tinggi:                   ")
        self.HeightLabelSourceDMS = wx.StaticText(self, label="Tinggi:                                 ")
        self.HeightTextCtrlSourceDD = wx.TextCtrl(self, value="")
        self.HeightTextCtrlSourceDMS = wx.TextCtrl(self, value="")

        #PCS Sumber
        self.NorthingLabelSource = wx.StaticText(self, label="Northing:                            ")
        self.EastingLabelSource = wx.StaticText(self, label="Easting:")
        self.NorthingTextCtrlSource = wx.TextCtrl(self, value="", size=(140, -1) )
        self.EastingTextCtrlSource = wx.TextCtrl(self, value="", size=(140, -1))
        self.NorthingLabelMetersSource = wx.StaticText(self, label="Meter")
        self.EastingLabelMetersSource = wx.StaticText(self, label="Meter")

        #Pilihan Sistem Koordinat Sumber
        self.CSSourceLabel = wx.StaticText(self, 
            label="Sistem Koordinat Sumber:")
        self.CSSourceComboBox = wx.ComboBox(self, choices=self.coordSystem, value=self.coordSystem[0],
            style=wx.CB_DROPDOWN | wx.TE_READONLY, size=(300, -1))

        #GCS Tujuan
        self.LatitudeLabelDest = wx.StaticText(self, label="Lintang:                              ")
        self.LatitudeTextCtrlDest = wx.TextCtrl(self, value="", style=wx.TE_READONLY, size=(140, -1))
        self.LongitudelabelDest = wx.StaticText(self, label="Bujur:")
        self.LongitudeTextCtrlDest = wx.TextCtrl(self, value="", style=wx.TE_READONLY, size=(140, -1))
        self.HeightLabelDest = wx.StaticText(self, label="Tinggi:")
        self.HeightTextCtrlDest = wx.TextCtrl(self, value="", style=wx.TE_READONLY, size=(140, -1))

        #Set Warna Disabled GCS
        self.disabled_color=(200,200,200)
        self.LatitudeTextCtrlDest.SetBackgroundColour(self.disabled_color)
        self.LongitudeTextCtrlDest.SetBackgroundColour(self.disabled_color)
        self.HeightTextCtrlDest.SetBackgroundColour(self.disabled_color)
        
        #PCS Tujuan
        self.NorthingLabelDest = wx.StaticText(self, label="Northing:                           ")
        self.EastingLabelDest = wx.StaticText(self, label="Easting:")
        self.NorthingTextCtrlDest = wx.TextCtrl(self, value="", style=wx.TE_READONLY, size=(140, -1))
        self.EastingTextCtrlDest = wx.TextCtrl(self, value="", style=wx.TE_READONLY, size=(140, -1))
        self.NorthingLabelMetersDest = wx.StaticText(self, label="Meter")
        self.EastingLabelMetersDest = wx.StaticText(self, label="Meter")

        #Set Warna Disabled PCS
        self.NorthingTextCtrlDest.SetBackgroundColour(self.disabled_color)
        self.EastingTextCtrlDest.SetBackgroundColour(self.disabled_color)

        #Pilihan Sistem Koordinat Tujuan
        self.CSDestLabel = wx.StaticText(self, 
            label="Sistem Koordinat Tujuan:")
        self.CSDestComboBox = wx.ComboBox(self, choices=self.coordSystem, value=self.coordSystem[0],
            style=wx.CB_DROPDOWN  | wx.TE_READONLY, size=(300, -1))

    def bindEvents(self):
        for control, event, handler in \
            [(self.TransformButton, wx.EVT_BUTTON, self.onTransform),
             (self.SwapButton, wx.EVT_BUTTON, self.onSwap),
             (self.ClearButton, wx.EVT_BUTTON, self.clearAllText),
             (self.IsiButton, wx.EVT_BUTTON, self.isiText),
             #(self.LatitudeTextCtrlSourceDD, wx.EVT_TEXT, self.onLatEntered),
             (self.LatitudeTextCtrlSourceDD, wx.EVT_TEXT, self.checkNSDD),
             #(self.LongitudeTextCtrlSourceDD, wx.EVT_TEXT, self.onLonEntered),
             (self.LongitudeTextCtrlSourceDD, wx.EVT_TEXT, self.checkWEDD),
             #(self.LatitudeTextCtrlSourceD, wx.EVT_TEXT, self.onLatEntered),
             (self.LatitudeTextCtrlSourceD, wx.EVT_TEXT, self.checkNSDMS),
             #(self.LongitudeTextCtrlSourceD, wx.EVT_TEXT, self.onLonEntered),
             (self.LongitudeTextCtrlSourceD, wx.EVT_TEXT, self.checkWEDMS),
             #(self.LatitudeTextCtrlSourceM, wx.EVT_TEXT, self.onLatEntered),
             #(self.LongitudeTextCtrlSourceM, wx.EVT_TEXT, self.onLonEntered),
             #(self.LatitudeTextCtrlSourceS, wx.EVT_TEXT, self.onLatEntered),
             #(self.LongitudeTextCtrlSourceS, wx.EVT_TEXT, self.onLonEntered),
             #(self.HeightTextCtrlSourceDD, wx.EVT_TEXT, self.onHeiEntered),
             #(self.HeightTextCtrlSourceDMS, wx.EVT_TEXT, self.onHeiEntered),
             (self.CSSourceComboBox, wx.EVT_TEXT, self.onCSSourceEntered),
             #(self.LatitudeTextCtrlDest, wx.EVT_TEXT, self.onLatEntered),
             #(self.LongitudeTextCtrlDest, wx.EVT_TEXT, self.onLonEntered),
             #(self.HeightTextCtrlDest, wx.EVT_TEXT, self.onHeiEntered),
             (self.CSDestComboBox, wx.EVT_TEXT, self.onCSDestEntered),
             (self.degreesRadioBox, wx.EVT_RADIOBOX, self.ChangeDDMS)]:
            control.Bind(event, handler)

    def doLayout(self):
        ''' Layout the controls that were created by createControls(). 
            Form.doLayout() will raise a NotImplementedError because it 
            is the responsibility of subclasses to layout the controls. '''
        raise NotImplementedError 

    # Callback methods:

    def onTransform(self, event):
        SKSumber = self.CSSourceComboBox.GetSelection()
        SKTujuan = self.CSDestComboBox.GetSelection()
        DD_DMS = self.degreesRadioBox.GetSelection()

        if SKSumber == 0:
            if DD_DMS == 0:
                if (self.LatitudeTextCtrlSourceDD.GetValue() == ''):
                     dlg = wx.MessageDialog(self, " Mohon Lengkapi Input Lintang", "Error", wx.OK)
                     dlg.ShowModal() # Shows it
                     dlg.Destroy() # finally destroy it when finished.
                elif (self.LongitudeTextCtrlSourceDD.GetValue() == ''):
                     dlg = wx.MessageDialog(self, " Mohon Lengkapi Input Bujur", "Error", wx.OK)
                     dlg.ShowModal() # Shows it
                     dlg.Destroy() # finally destroy it when finished.
                elif (self.HeightTextCtrlSourceDD.GetValue() == ''):
                     dlg = wx.MessageDialog(self, " Mohon Lengkapi Input Tinggi", "Error", wx.OK)
                     dlg.ShowModal() # Shows it
                     dlg.Destroy() # finally destroy it when finished
                else:
                     lintang = math.fabs(float(self.LatitudeTextCtrlSourceDD.GetValue()))
                     bujur = math.fabs(float(self.LongitudeTextCtrlSourceDD.GetValue()))
                     tinggi = float(self.HeightTextCtrlSourceDD.GetValue())
                     #check utara selatan
                     if self.LatitudeNSDD == 'Selatan':
                        lintang=0-lintang
                     if self.LongitudeWEDD == 'Barat':
                        bujur=360-bujur
            else:
                if (self.LatitudeTextCtrlSourceD.GetValue() == '') and (self.LatitudeTextCtrlSourceM.GetValue() == '') and (self.LatitudeTextCtrlSourceS.GetValue() == ''):
                     dlg = wx.MessageDialog(self, " Mohon Lengkapi Input Lintang", "Error", wx.OK)
                     dlg.ShowModal() # Shows it
                     dlg.Destroy() # finally destroy it when finished.
                elif (self.LongitudeTextCtrlSourceD.GetValue() == '') and (self.LongitudeTextCtrlSourceM.GetValue() == '') and (self.LongitudeTextCtrlSourceS.GetValue() == ''):
                     dlg = wx.MessageDialog(self, " Mohon Lengkapi Input Bujur", "Error", wx.OK)
                     dlg.ShowModal() # Shows it
                     dlg.Destroy() # finally destroy it when finished.
                elif (self.HeightTextCtrlSourceDMS.GetValue() == ''):
                     dlg = wx.MessageDialog(self, " Mohon Lengkapi Input Tinggi", "Error", wx.OK)
                     dlg.ShowModal() # Shows it
                     dlg.Destroy() # finally destroy it when finished
                else:
                     lintang = math.fabs(float(self.LatitudeTextCtrlSourceD.GetValue())) + math.fabs(float(self.LatitudeTextCtrlSourceM.GetValue()))/60 + math.fabs(float(self.LatitudeTextCtrlSourceS.GetValue()))/3600
                     bujur = math.fabs(float(self.LongitudeTextCtrlSourceD.GetValue())) + math.fabs(float(self.LongitudeTextCtrlSourceM.GetValue()))/60 + math.fabs(float(self.LongitudeTextCtrlSourceS.GetValue()))/3600
                     tinggi = float(self.HeightTextCtrlSourceDMS.GetValue())
                     #check utara selatan
                     if self.LatitudeNSDMS.GetValue() == 'Selatan':
                        lintang=0-lintang
                     if self.LongitudeWEDMS.GetValue() == 'Barat':
                        bujur=360-bujur
            self.__log('User memasukkan lintang: %f'%lintang)
            self.__log('User memasukkan bujur: %f'%bujur)
            self.__log('User memasukkan tinggi: %f'%tinggi)
        else:
            northing = float(self.NorthingTextCtrlSource.GetValue())
            easting = float(self.EastingTextCtrlSource.GetValue())
            self.__log('User memasukkan northing: %f'%northing)
            self.__log('User memasukkan easting: %f'%easting)

        #do transform 
        if (self.CSSourceComboBox.GetSelection() == 0) and (self.CSDestComboBox.GetSelection() == 1):
            string = "Transformasi dilakukan dari " + str(self.coordSystem[self.CSSourceComboBox.GetSelection()]) + " ke " + str(self.coordSystem[self.CSDestComboBox.GetSelection()])
            self.__log(string)
            koordSementara = latlonh2sementara(lintang,bujur,tinggi,self.LatCentral,self.LongCentral,self.HeightCentral)
            self.NorthingTextCtrlDest.SetValue("%.15f"%koordSementara[0])
            self.EastingTextCtrlDest.SetValue("%.15f"%koordSementara[1])
            string = "Hasil transformasi Northing: %.15f" %koordSementara[0]
            self.__log(string)
            string = "Hasil transformasi Easting: %.15f" %koordSementara[1]
            self.__log(string)
        elif (self.CSSourceComboBox.GetSelection() == 1) and (self.CSDestComboBox.GetSelection() == 0):
            string = "Transformasi dilakukan dari " + str(self.coordSystem[self.CSSourceComboBox.GetSelection()]) + " ke " + str(self.coordSystem[self.CSDestComboBox.GetSelection()])
            self.__log(string)
            koordLatLong = sementara2latlonh(northing,easting,self.LatCentral,self.LongCentral,self.HeightCentral)
            self.LatitudeTextCtrlDest.SetValue("%.15f"%koordLatLong[0])
            self.LongitudeTextCtrlDest.SetValue("%.15f"%koordLatLong[1])
            self.HeightTextCtrlDest.SetValue("-")
            string = "Hasil transformasi Lintang: %.15f" %koordLatLong[0]
            self.__log(string)
            string = "Hasil transformasi Bujur: %.15f" %koordLatLong[1]
            self.__log(string)

        else:
            string = "Metode Transformasi dari " + str(self.coordSystem[self.CSSourceComboBox.GetSelection()]) + " ke " + str(self.coordSystem[self.CSDestComboBox.GetSelection()]) + " tidak ada"
            dlg = wx.MessageDialog(self, string, "Error", wx.OK)
            dlg.ShowModal() # Shows it
            dlg.Destroy() # finally destroy it when finished

    '''def doTransform(self):
        #check source dan tujuan
        if (self.CSSourceComboBox.GetSelection() == 0) and (self.CSDestComboBox.GetSelection() == 1):
            string = "Transformasi dilakukan dari " + str(self.coordSystem[self.CSSourceComboBox.GetSelection()]) + " ke " + str(self.coordSystem[self.CSDestComboBox.GetSelection()])
            self.__log(string)
            latlonh2sementara()'''


    def isiText(self, event):
        if self.CSSourceComboBox.GetSelection() == 0:
            self.__log('Input diisi dengan data contoh')
            self.clearAllTextSrc()
            self.CSSourceComboBox.SetSelection(0)
            self.CSDestComboBox.SetSelection(1)
            self.degreesRadioBox.SetSelection(1)
            self.LatitudeTextCtrlSourceD.SetValue("-6")
            self.LatitudeTextCtrlSourceM.SetValue("53")
            self.LatitudeTextCtrlSourceS.SetValue("27.97")
            self.LongitudeTextCtrlSourceD.SetValue("107")
            self.LongitudeTextCtrlSourceM.SetValue("36")
            self.LongitudeTextCtrlSourceS.SetValue("37.42")
            self.HeightTextCtrlSourceDMS.SetValue("788.8369")
            self.checkLayout()
        elif self.CSSourceComboBox.GetSelection() == 1:
            self.__log('Input diisi dengan data contoh')
            self.clearAllTextSrc()
            self.CSSourceComboBox.SetSelection(1)
            self.CSDestComboBox.SetSelection(0)
            self.NorthingTextCtrlSource.SetValue("-215.841285355747857")
            self.EastingTextCtrlSource.SetValue("-767245.813306005671620")
            self.checkLayout()


    def onCSDestEntered(self, event):
        self.__log('User memilih Sistem Koordinat tujuan: %s'%event.GetString())
        self.checkLayout()
        self.clearAllTextDest()

    def onCSSourceEntered(self, event):
        self.__log('User memilih Sistem Koordinat sumber: %s'%event.GetString())
        self.checkLayout()
        self.clearAllTextSrc()
        #self.__log('Pilihan Nomer: %s'%self.CSSourceComboBox.GetSelection())

    def checkLayout(self):
        #check layout GCS/PCS Source
        if  self.CSSourceComboBox.GetSelection() == 0:
            self.gridSizer1.Show(self.gridSizer1bGCS)
            #check layout DD/DMS
            if self.degreesRadioBox.GetSelection() == 0:
                 self.gridSizer1bGCS1.Show(self.gridSizer1bGCS1i)
                 self.gridSizer1bGCS1.Hide(self.gridSizer1bGCS1ii)           
            else:
                 self.gridSizer1bGCS1.Hide(self.gridSizer1bGCS1i)
                 self.gridSizer1bGCS1.Show(self.gridSizer1bGCS1ii)           
            self.gridSizer1.Hide(self.gridSizer1bPCS)
            self.Layout()
        else:
            self.gridSizer1.Show(self.gridSizer1bPCS)
            self.gridSizer1.Hide(self.gridSizer1bGCS)
            self.Layout()

        #check layout GCS/PCS Destination
        if  self.CSDestComboBox.GetSelection() == 0:
            self.gridSizer2b.Show(self.gridSizer2bGCS)
            self.gridSizer2b.Hide(self.gridSizer2bPCS)
            self.Layout()
        else:
            self.gridSizer2b.Show(self.gridSizer2bPCS)
            self.gridSizer2b.Hide(self.gridSizer2bGCS)
            self.Layout()
        

    def onSave(self,event):
        self.__log('User menekan tombol dengan id %d'%event.GetId())

    def onSwap(self,event):
        
        self.__log('Koordinat Sumber and Koordinat Tujuan Ditukar')
       # self.__log('Koordinat Sumber : %s'%self.coordSystem[self.CSSourceComboBox.GetSelection()])
       # self.__log('Koordinat Tujuan : %s'%self.coordSystem[self.CSDestComboBox.GetSelection()])
        #simpan isian koordinat tujuan
        #hapus isian koordinat sumber dan tujuan
        self.clearAllTextSrc()
        self.clearAllTextDest()
        dummy=self.CSSourceComboBox.GetSelection()
        self.CSSourceComboBox.SetSelection(self.CSDestComboBox.GetSelection())
        self.CSDestComboBox.SetSelection(dummy)
        self.checkLayout()

    def onLatEntered(self, event):
        self.__log('User memasukkan Lintang: %s'%event.GetString())

    def checkNSDD(self, event):
        self.__changeNSDD('%s'%event.GetString())
        event.Skip()

    def checkNSDMS(self, event):
        self.__changeNSDMS('%s'%event.GetString())
        event.Skip()

    def onLatChanged(self, event):
        self.__log('User menulis Lintang: %d'%event.GetKeyCode())
        event.Skip()

    def onLonEntered(self, event):
        self.__log('User memasukkan Bujur: %s'%event.GetString())

    def checkWEDD(self, event):
        self.__changeWEDD('%s'%event.GetString())
        event.Skip()

    def checkWEDMS(self, event):
        self.__changeWEDMS('%s'%event.GetString())
        event.Skip()

    def onLonChanged(self, event):
        self.__log('User menulis Bujur: %d'%event.GetKeyCode())
        event.Skip()

    def onHeiEntered(self, event):
        self.__log('User memasukkan Tinggi: %s'%event.GetString())

    def onHeiChanged(self, event):
        self.__log('User menulis Tinggi: %d'%event.GetKeyCode())
        event.Skip()

    def clearAllText(self, event):
        self.clearAllTextSrc()
        self.clearAllTextDest()
        self.__log('Semua teks dihapus')
        '''print self.LatCentral
        print self.LongCentral
        print self.HeightCentral
        print self.GunakanDefault
        print self.DDDMS'''

    def clearAllTextSrc(self):
        self.LatitudeTextCtrlSourceDD.Clear()
        self.LatitudeTextCtrlSourceD.Clear() 
        self.LatitudeTextCtrlSourceM.Clear()  
        self.LatitudeTextCtrlSourceS.Clear() 
        self.LongitudeTextCtrlSourceDD.Clear() 
        self.LongitudeTextCtrlSourceD.Clear()  
        self.LongitudeTextCtrlSourceM.Clear()  
        self.LongitudeTextCtrlSourceS.Clear() 
        self.HeightTextCtrlSourceDD.Clear() 
        self.HeightTextCtrlSourceDMS.Clear() 
        self.NorthingTextCtrlSource.Clear()    
        self.EastingTextCtrlSource.Clear() 

    def clearAllTextDest(self):
        self.LatitudeTextCtrlDest.Clear()
        self.LongitudeTextCtrlDest.Clear()  
        self.HeightTextCtrlDest.Clear() 
        self.NorthingTextCtrlDest.Clear()    
        self.EastingTextCtrlDest.Clear() 

    # Helper method(s):

    def ChangeDDMS(self, event):
        pilihan = event.GetInt()
        if pilihan == 0:
            self.checkLayout()
            self.clearAllTextSrc()
            self.__log('User memilih format DDD : %s'%self.degrees[event.GetInt()])
        elif pilihan == 1:     
            self.checkLayout()
            self.clearAllTextSrc()
            self.__log('User memilih format DMS : %s'%self.degrees[event.GetInt()])
        else:
            self.__log('User memilih format error : %s'%self.degrees[event.GetInt()])

    def __log(self, message):
        ''' Private method to append a string to the logger text
            control. '''
        self.logger.AppendText('%s\n'%message)

    def __changeNSDD(self, stringZ):
        if len(stringZ) > 0:
            if stringZ[0] == "-":
                self.LatitudeNSDD.ChangeValue('Selatan')
            else:
                self.LatitudeNSDD.ChangeValue('Utara')

    def __changeWEDD(self, stringZ):
        if len(stringZ) > 0:
            if stringZ[0] == "-":
                self.LongitudeWEDD.ChangeValue('Barat')
            else:
                self.LongitudeWEDD.ChangeValue('Timur')

    def __changeNSDMS(self, stringZ):
        if len(stringZ) > 0:
            if stringZ[0] == "-":
                self.LatitudeNSDMS.ChangeValue('Selatan')
            else:
                self.LatitudeNSDMS.ChangeValue('Utara')

    def __changeWEDMS(self, stringZ):
        if len(stringZ) > 0:
            if stringZ[0] == "-":
                self.LongitudeWEDMS.ChangeValue('Barat')
            else:
                self.LongitudeWEDMS.ChangeValue('Timur')

class FormWithSizer1(Form1):
    def doLayout(self):
        ''' Layout the controls by means of sizers. '''

        # A horizontal BoxSizer will contain the GridSizer (on the left)
        # and the logger text control (on the right):
        self.boxSizerH = wx.BoxSizer(orient=wx.HORIZONTAL)
        self.gridSizerV = wx.FlexGridSizer(rows=3, cols=1, vgap=8, hgap=8)

        # GridSizer Sumber
        self.gridSizer1 = wx.FlexGridSizer(rows=3, cols=1, vgap=8, hgap=8)
        self.labeler1 = wx.StaticBox(self, -1, 'Koordinat Sumber:')
        self.boxStatic1 = wx.StaticBoxSizer(self.labeler1,wx.VERTICAL)

        # Anggota GridSizer Sumber
        self.gridSizer1a = wx.FlexGridSizer(rows=1, cols=2, vgap=8, hgap=8)
        self.gridSizer1bGCS = wx.FlexGridSizer(rows=1, cols=2, vgap=8, hgap=8)
        self.gridSizer1bPCS = wx.FlexGridSizer(rows=3, cols=3, vgap=8, hgap=8)
        self.gridSizer1bGCS1 = wx.FlexGridSizer(rows=2, cols=1, vgap=8, hgap=8)
        self.gridSizer1bGCS1i = wx.FlexGridSizer(rows=3, cols=3, vgap=8, hgap=8)
        self.gridSizer1bGCS1ii = wx.FlexGridSizer(rows=2, cols=1, vgap=8, hgap=8)
        self.gridSizer1bGCS1iia = wx.FlexGridSizer(rows=2, cols=5, vgap=8, hgap=8)
        self.gridSizer1bGCS1iib = wx.FlexGridSizer(rows=1, cols=2, vgap=8, hgap=8)
        self.gridSizer1bGCS2 = wx.FlexGridSizer(rows=2, cols=1, vgap=8, hgap=8)

        # GridSizer Tujuan
        self.gridSizer2 = wx.FlexGridSizer(rows=2, cols=1, vgap=8, hgap=8)
        self.labeler2 = wx.StaticBox(self, -1, 'Koordinat Tujuan:')
        self.boxStatic2 = wx.StaticBoxSizer(self.labeler2,wx.VERTICAL)      

        # Anggota GridSizer Tujuan
        self.gridSizer2a = wx.FlexGridSizer(rows=1, cols=2, vgap=8, hgap=8)
        self.gridSizer2b = wx.FlexGridSizer(rows=2, cols=1, vgap=8, hgap=8)
        self.gridSizer2bGCS = wx.FlexGridSizer(rows=3, cols=2, vgap=8, hgap=8)
        self.gridSizer2bPCS = wx.FlexGridSizer(rows=3, cols=3, vgap=8, hgap=8)

        # GridSizer Tombol
        self.gridSizer3 = wx.FlexGridSizer(rows=1, cols=4, vgap=8, hgap=8)

        # Prepare some reusable arguments for calling sizer.Add():
        expandOption = dict(flag=wx.EXPAND)
        textWrap = dict(flag=wx.SHRINK)
        noOptions = dict()
        emptySpace = ((0, 0), noOptions)
    
        # Add the controls to the sizers:
        for control, options in \
                [(self.gridSizer1a, noOptions),
                 (self.gridSizer1bGCS, noOptions),
                 (self.gridSizer1bPCS, noOptions)]:
            self.gridSizer1.Add(control, **options)

        for control, options in \
                [(self.CSSourceLabel, noOptions),
                 (self.CSSourceComboBox, expandOption)]:
            self.gridSizer1a.Add(control, **options)

        for control, options in \
                [(self.gridSizer1bGCS1, noOptions),
                 (self.gridSizer1bGCS2, noOptions)]:
            self.gridSizer1bGCS.Add(control, **options)

        for control, options in \
                [(self.NorthingLabelSource, noOptions),
                 (self.NorthingTextCtrlSource, expandOption),
                 (self.NorthingLabelMetersSource, noOptions),
                 (self.EastingLabelSource, noOptions),
                 (self.EastingTextCtrlSource, expandOption),
                 (self.EastingLabelMetersSource, noOptions),
                 emptySpace]:
            self.gridSizer1bPCS.Add(control, **options)    

        self.gridSizer1.Hide(self.gridSizer1bPCS)

        for control, options in \
                [(self.gridSizer1bGCS1i, expandOption),
                 (self.gridSizer1bGCS1ii, expandOption)]:
            self.gridSizer1bGCS1.Add(control, **options)

        for control, options in \
                [(self.LatitudeLabelSourceDD, noOptions),
                 (self.LatitudeTextCtrlSourceDD, expandOption),
                 (self.LatitudeNSDD, textWrap),
                 (self.LongitudelabelSourceDD, noOptions),
                 (self.LongitudeTextCtrlSourceDD, expandOption),
                 (self.LongitudeWEDD, textWrap),
                 (self.HeightLabelSourceDD, noOptions),
                 (self.HeightTextCtrlSourceDD, expandOption),
                 emptySpace]:
            self.gridSizer1bGCS1i.Add(control, **options)

        for control, options in \
                [(self.gridSizer1bGCS1iia, expandOption),
                 (self.gridSizer1bGCS1iib, expandOption)]:
            self.gridSizer1bGCS1ii.Add(control, **options)

        for control, options in \
                [(self.LatitudeLabelSourceDMS, noOptions),
                 (self.LatitudeTextCtrlSourceD, noOptions),
                 (self.LatitudeTextCtrlSourceM, noOptions),
                 (self.LatitudeTextCtrlSourceS, noOptions),
                 (self.LatitudeNSDMS, textWrap),
                 (self.LongitudelabelSourceDMS, noOptions),
                 (self.LongitudeTextCtrlSourceD, noOptions),
                 (self.LongitudeTextCtrlSourceM, noOptions),
                 (self.LongitudeTextCtrlSourceS, noOptions),
                 (self.LongitudeWEDMS, textWrap)]:
            self.gridSizer1bGCS1iia.Add(control, **options)

        for control, options in \
                [(self.HeightLabelSourceDMS, noOptions),
                 (self.HeightTextCtrlSourceDMS, expandOption)]:
            self.gridSizer1bGCS1iib.Add(control, **options)

        self.gridSizer1bGCS1.Hide(self.gridSizer1bGCS1ii)

        for control, options in \
                [(self.degreesRadioBox, noOptions),
                emptySpace]:
            self.gridSizer1bGCS2.Add(control, **options)

        for control, options in \
                [(self.CSDestLabel, noOptions),
                 (self.CSDestComboBox, expandOption)]:
            self.gridSizer2a.Add(control, **options)                             

        for control, options in \
                [(self.LatitudeLabelDest, noOptions),
                 (self.LatitudeTextCtrlDest, expandOption),
                 (self.LongitudelabelDest, noOptions),
                 (self.LongitudeTextCtrlDest, expandOption),
                 (self.HeightLabelDest, noOptions),
                 (self.HeightTextCtrlDest, expandOption)]:
            self.gridSizer2bGCS.Add(control, **options)            

        for control, options in \
                [(self.NorthingLabelDest, noOptions),
                 (self.NorthingTextCtrlDest, expandOption),
                 (self.NorthingLabelMetersDest, noOptions),
                 (self.EastingLabelDest, noOptions),
                 (self.EastingTextCtrlDest, expandOption),
                 (self.EastingLabelMetersDest, noOptions),
                 emptySpace]:
            self.gridSizer2bPCS.Add(control, **options)            

        for control, options in \
                [(self.gridSizer2bGCS, noOptions),
                 (self.gridSizer2bPCS, noOptions)]:
            self.gridSizer2b.Add(control, **options)     

        self.gridSizer2b.Hide(self.gridSizer2bPCS)

        for control, options in \
                [(self.gridSizer2a, noOptions),
                 (self.gridSizer2b, noOptions)]:
            self.gridSizer2.Add(control, **options)          

        for control, options in \
                [#(self.TransformButton, dict(flag=wx.ALIGN_CENTER)),
                 (self.TransformButton, dict(flag=wx.ALIGN_CENTER)),
                 (self.SwapButton, noOptions),
                 (self.ClearButton, noOptions),
                 (self.IsiButton, noOptions)]:
            self.gridSizer3.Add(control, **options) 

        self.boxStatic1.Add(self.gridSizer1)
        self.boxStatic2.Add(self.gridSizer2)

        for control, options in \
                [(self.boxStatic1, dict(border=5, flag=wx.ALL)),
                 (self.boxStatic2, dict(border=5, flag=wx.ALL)),
                 (self.gridSizer3, noOptions)]:
            self.gridSizerV.Add(control, **options)

        for control, options in \
                [(self.gridSizerV, dict(border=5, flag=wx.ALL)),
                 (self.logger, dict(border=5, flag=wx.ALL|wx.EXPAND, 
                    proportion=1))]:
            self.boxSizerH.Add(control, **options)

        self.SetSizerAndFit(self.boxSizerH)

    def GetCoordCentralValue(self):
        return([self.GunakanDefault, self.DDDMS, self.LatCentral,self.LongCentral,self.HeightCentral])
        #if self.form1 is not None:
        #    return([self.form1.LatCentral,self.form1.LongCentral,self.form1.HeightCentral])
        #else:
        #    return('None')

    def SetCoordCentralValue(self, GunakanDefault, DDDMS, LatCentral, LongCentral, HeightCentral):
        self.GunakanDefault = GunakanDefault
        self.DDDMS = DDDMS
        self.LatCentral = LatCentral
        self.LongCentral = LongCentral
        self.HeightCentral = HeightCentral

class MyDialog(wx.Dialog): 
    def __init__(self, parent, title): 
        super(MyDialog, self).__init__(parent, title = title, size = (250,150)) 
        panel = wx.Panel(self) 
        self.btn = wx.Button(panel, wx.ID_OK, label = "ok", size = (50,20), pos = (75,50))

class OptionsDialog(wx.Dialog):
    def __init__(self, parent, title): 
        super(OptionsDialog, self).__init__(parent, title = title) 

        self.parent_frame = parent
        self.KoordinatSentral = self.parent_frame.GetCoordCentralValue()
                
        #definisi array
        self.degrees = ['dd.dddd', 'dd mm ss.ssss']

        #definisi sumber
        self.defaultCheckBox = wx.CheckBox(self, label="Gunakan nilai default")
        self.defaultCheckBox.SetValue(1)
        self.degreesRadioBox = wx.RadioBox(self, choices=self.degrees, majorDimension=1, style=wx.RA_SPECIFY_ROWS | wx.TE_CENTRE, size=(0, -1))
        self.degreesRadioBox.Disable()
        self.degreesRadioBox.SetSelection(0)
        self.LatitudeLabelSourceDD = wx.StaticText(self, label="Lintang: ")
        self.LatitudeLabelSourceDMS = wx.StaticText(self, label="Lintang: ")
        self.LatitudeTextCtrlSourceDD = wx.TextCtrl(self, value="", style=wx.TE_READONLY, size=(140, -1))
        self.LatitudeTextCtrlSourceD = wx.TextCtrl(self, value="", style=wx.TE_READONLY | wx.TE_CENTRE, size=(40, -1))
        wx.TextCtrl.SetMaxLength(self.LatitudeTextCtrlSourceD,4)
        self.LatitudeTextCtrlSourceM = wx.TextCtrl(self, value="", style=wx.TE_READONLY | wx.TE_CENTRE, size=(40, -1))
        wx.TextCtrl.SetMaxLength(self.LatitudeTextCtrlSourceM,2)
        self.LatitudeTextCtrlSourceS = wx.TextCtrl(self, value="", style=wx.TE_READONLY | wx.TE_CENTRE, size=(40, -1))
        wx.TextCtrl.SetMaxLength(self.LatitudeTextCtrlSourceS,5)
        self.LatitudeNSDD = wx.TextCtrl(self, value="Selatan", style=wx.TE_READONLY | wx.TE_CENTRE, size=(50, -1))
        self.LatitudeNSDMS = wx.TextCtrl(self, value="Selatan", style=wx.TE_READONLY | wx.TE_CENTRE, size=(50, -1))
        self.LongitudelabelSourceDD = wx.StaticText(self, label="Bujur: ")
        self.LongitudelabelSourceDMS = wx.StaticText(self, label="Bujur: ")
        self.LongitudeTextCtrlSourceDD = wx.TextCtrl(self, value="", size=(140, -1))
        self.LongitudeTextCtrlSourceD = wx.TextCtrl(self, value="", style=wx.TE_READONLY | wx.TE_CENTRE, size=(40, -1))
        wx.TextCtrl.SetMaxLength(self.LongitudeTextCtrlSourceD,4)
        self.LongitudeTextCtrlSourceM = wx.TextCtrl(self, value="", style=wx.TE_READONLY | wx.TE_CENTRE, size=(40, -1))
        wx.TextCtrl.SetMaxLength(self.LongitudeTextCtrlSourceM,2)
        self.LongitudeTextCtrlSourceS = wx.TextCtrl(self, value="", style=wx.TE_READONLY | wx.TE_CENTRE, size=(40, -1))
        wx.TextCtrl.SetMaxLength(self.LongitudeTextCtrlSourceS,5)
        self.LongitudeWEDD = wx.TextCtrl(self, value="Timur", style=wx.TE_READONLY | wx.TE_CENTRE, size=(50, -1))
        self.LongitudeWEDMS = wx.TextCtrl(self, value="Timur", style=wx.TE_READONLY | wx.TE_CENTRE, size=(50, -1))
        self.HeightLabelSourceDD = wx.StaticText(self, label="Tinggi: ")
        self.HeightLabelSourceDMS = wx.StaticText(self, label="Tinggi:   ")
        self.HeightTextCtrlSourceDD = wx.TextCtrl(self, value="", style=wx.TE_READONLY, size=(140, -1))
        self.HeightTextCtrlSourceDMS = wx.TextCtrl(self, value="", style=wx.TE_READONLY, size=(140, -1))
        self.dummy = wx.StaticText(self, label="")

        #definisi button 
        self.button_ok = wx.Button(self, wx.ID_OK, label='&Oke')
        self.button_apply = wx.Button(self, wx.APPLY, label='&Terapkan')
        self.button_cancel = wx.Button(self, wx.ID_CANCEL, label='&Batal')

        #bind button              
        self.button_ok.Bind(wx.EVT_BUTTON, self.okEvent)
        self.button_apply.Bind(wx.EVT_BUTTON, self.applyEvent)
        self.button_cancel.Bind(wx.EVT_BUTTON, self.cancel_button)
        self.degreesRadioBox.Bind(wx.EVT_RADIOBOX, self.ChangeDDMS)
        self.defaultCheckBox.Bind(wx.EVT_CHECKBOX, self.CheckDefaultCentang)
        self.LatitudeTextCtrlSourceDD.Bind(wx.EVT_TEXT, self.checkNSDD)
        self.LongitudeTextCtrlSourceDD.Bind(wx.EVT_TEXT, self.checkWEDD)
        self.LatitudeTextCtrlSourceD.Bind(wx.EVT_TEXT, self.checkNSDMS)
        self.LongitudeTextCtrlSourceD.Bind(wx.EVT_TEXT, self.checkWEDMS)

        #definisi layout
        #self.panel = wx.Panel(self)
        self.vbox = wx.BoxSizer(wx.VERTICAL)
        self.gridSizerV = wx.FlexGridSizer(rows=2, cols=1, vgap=8, hgap=8)

        #self.judul = wx.StaticText('Koordinat Meridian Sentral TM Sementara:')
        #self.FontJudul = wx.SystemSettings.GetFont(1)
        self.FontJudul = wx.SystemSettings.GetFont(wx.SYS_SYSTEM_FONT)
        self.FontJudul.MakeBold()
        self.FontJudul.SetPointSize(10)
        self.labeler1 = wx.StaticBox(self, -1, 'Koordinat Meridian Sentral TM Sementara:')
        self.labeler1.SetFont(self.FontJudul)
        self.boxStatic1 = wx.StaticBoxSizer(self.labeler1,wx.VERTICAL)
        self.gridSizer1 = wx.FlexGridSizer(rows=3, cols=1, vgap=8, hgap=8)

        self.gridSizer1a = wx.BoxSizer(wx.HORIZONTAL)
        self.gridSizer1b = wx.FlexGridSizer(rows=2, cols=1, vgap=8, hgap=8)
        self.gridSizer1bi = wx.FlexGridSizer(rows=3, cols=3, vgap=8, hgap=8)
        self.gridSizer1bii = wx.FlexGridSizer(rows=2, cols=1, vgap=8, hgap=8)
        self.gridSizer1biia = wx.FlexGridSizer(rows=2, cols=5, vgap=8, hgap=8)
        self.gridSizer1biib = wx.FlexGridSizer(rows=1, cols=2, vgap=8, hgap=8)
        self.gridSizer1c = wx.BoxSizer(wx.HORIZONTAL)
        
        self.gridSizer2 = wx.FlexGridSizer(rows=1, cols=3, vgap=8, hgap=8)

        # Prepare some reusable arguments for calling sizer.Add():
        radioExpand = dict(flag=wx.EXPAND|wx.LEFT|wx.RIGHT|wx.TOP|wx.ALIGN_CENTER , border=0)
        expandOption = dict(flag=wx.EXPAND)
        textWrap = dict(flag=wx.SHRINK)
        noOptions = dict()
        emptySpace = ((0, 0), noOptions)

        self.vbox.Add(self.gridSizerV, border=20, flag=wx.ALL)
        self.boxStatic1.Add(self.gridSizer1)

        for control, options in \
                [(self.boxStatic1, dict(border=5, flag=wx.ALL)),
                 (self.gridSizer2, dict(border=5, flag=wx.ALL))]:
            self.gridSizerV.Add(control, **options)

        for control, options in \
                [(self.gridSizer1a, noOptions),
                 (self.gridSizer1b, noOptions),
                 (self.gridSizer1c, noOptions)]:
            self.gridSizer1.Add(control, **options)

        for control, options in \
                [(self.degreesRadioBox, dict(border=20, flag=wx.EXPAND|wx.LEFT))]:
            self.gridSizer1a.Add(control, **options)

        for control, options in \
                [(self.gridSizer1bi, expandOption),
                 (self.gridSizer1bii, expandOption)]:
            self.gridSizer1b.Add(control, **options)

        for control, options in \
                [(self.LatitudeLabelSourceDD, noOptions),
                 (self.LatitudeTextCtrlSourceDD, expandOption),
                 (self.LatitudeNSDD, textWrap),
                 (self.LongitudelabelSourceDD, noOptions),
                 (self.LongitudeTextCtrlSourceDD, expandOption),
                 (self.LongitudeWEDD, textWrap),
                 (self.HeightLabelSourceDD, noOptions),
                 (self.HeightTextCtrlSourceDD, expandOption),
                 emptySpace]:
            self.gridSizer1bi.Add(control, **options)

        for control, options in \
                [(self.gridSizer1biia, expandOption),
                 (self.gridSizer1biib, expandOption)]:
            self.gridSizer1bii.Add(control, **options)

        for control, options in \
                [(self.LatitudeLabelSourceDMS, noOptions),
                 (self.LatitudeTextCtrlSourceD, noOptions),
                 (self.LatitudeTextCtrlSourceM, noOptions),
                 (self.LatitudeTextCtrlSourceS, noOptions),
                 (self.LatitudeNSDMS, textWrap),
                 (self.LongitudelabelSourceDMS, noOptions),
                 (self.LongitudeTextCtrlSourceD, noOptions),
                 (self.LongitudeTextCtrlSourceM, noOptions),
                 (self.LongitudeTextCtrlSourceS, noOptions),
                 (self.LongitudeWEDMS, textWrap)]:
            self.gridSizer1biia.Add(control, **options)

        for control, options in \
                [(self.HeightLabelSourceDMS, noOptions),
                 (self.HeightTextCtrlSourceDMS, expandOption)]:
            self.gridSizer1biib.Add(control, **options)

        self.gridSizer1b.Hide(self.gridSizer1bii)

        for control, options in \
                [(self.dummy, dict(border=70, flag=wx.LEFT)),
                (self.defaultCheckBox, dict(border=15, flag=wx.EXPAND|wx.TOP|wx.BOTTOM))]:
            self.gridSizer1c.Add(control, **options)

        for control, options in \
                [(self.button_ok, noOptions),
                (self.button_apply, noOptions),
                (self.button_cancel, noOptions)]:
            self.gridSizer2.Add(control, **options)        

        #run script
        self.SetSizerAndFit(self.vbox)
        self.CheckSimpan()

    def ChangeDDMS(self, event):
        self.checkLayout()
        #self.clearAllTextSrc()

    def CheckSimpan(self):
        if not self.KoordinatSentral[0]: #pilihan default no
            self.defaultCheckBox.SetValue(0)
            self.setIsi(self.KoordinatSentral[2], self.KoordinatSentral[3], self.KoordinatSentral[4])
        else: #pilihan default yes
            self.defaultCheckBox.SetValue(1)
            self.setIsi(-6.89092328888889, 107.61234715277800, 789.2737)
        
        if self.KoordinatSentral[1] == 0: #pilihan DD
            self.degreesRadioBox.SetSelection(0)
            self.checkLayout()
        else: #pilihan DMS
            self.degreesRadioBox.SetSelection(1)
            self.checkLayout()

        self.CheckDefaultNoEvt()

    def CheckDefaultCentang(self, event):
        self.CheckDefaultNoEvt()
        self.setIsi(-6.89092328888889, 107.61234715277800, 789.2737)

    def CheckDefaultNoEvt(self):
        if not self.defaultCheckBox.GetValue():
            self.degreesRadioBox.Enable()
            self.LatitudeTextCtrlSourceDD.SetEditable(1)
            self.LongitudeTextCtrlSourceDD.SetEditable(1)
            self.HeightTextCtrlSourceDD.SetEditable(1)
            self.LatitudeTextCtrlSourceD.SetEditable(1)
            self.LatitudeTextCtrlSourceM.SetEditable(1)
            self.LatitudeTextCtrlSourceS.SetEditable(1)
            self.LongitudeTextCtrlSourceD.SetEditable(1)
            self.LongitudeTextCtrlSourceM.SetEditable(1)
            self.LongitudeTextCtrlSourceS.SetEditable(1)
            self.HeightTextCtrlSourceDMS.SetEditable(1)
            self.LatitudeTextCtrlSourceDD.SetBackgroundColour((255,255,255))
            self.LongitudeTextCtrlSourceDD.SetBackgroundColour((255,255,255))
            self.HeightTextCtrlSourceDD.SetBackgroundColour((255,255,255))
            self.LatitudeTextCtrlSourceD.SetBackgroundColour((255,255,255))
            self.LatitudeTextCtrlSourceM.SetBackgroundColour((255,255,255))
            self.LatitudeTextCtrlSourceS.SetBackgroundColour((255,255,255))
            self.LongitudeTextCtrlSourceD.SetBackgroundColour((255,255,255))
            self.LongitudeTextCtrlSourceM.SetBackgroundColour((255,255,255))
            self.LongitudeTextCtrlSourceS.SetBackgroundColour((255,255,255))
            self.HeightTextCtrlSourceDMS.SetBackgroundColour((255,255,255))
        else:
            self.degreesRadioBox.Disable()
            self.LatitudeTextCtrlSourceDD.SetEditable(0)
            self.LongitudeTextCtrlSourceDD.SetEditable(0)
            self.HeightTextCtrlSourceDD.SetEditable(0)
            self.LatitudeTextCtrlSourceD.SetEditable(0)
            self.LatitudeTextCtrlSourceM.SetEditable(0)
            self.LatitudeTextCtrlSourceS.SetEditable(0)
            self.LongitudeTextCtrlSourceD.SetEditable(0)
            self.LongitudeTextCtrlSourceM.SetEditable(0)
            self.LongitudeTextCtrlSourceS.SetEditable(0)
            self.HeightTextCtrlSourceDMS.SetEditable(0)
            self.disabled_color=(210,210,210)
            self.LatitudeTextCtrlSourceDD.SetBackgroundColour(self.disabled_color)
            self.LongitudeTextCtrlSourceDD.SetBackgroundColour(self.disabled_color)
            self.HeightTextCtrlSourceDD.SetBackgroundColour(self.disabled_color)
            self.LatitudeTextCtrlSourceD.SetBackgroundColour(self.disabled_color)
            self.LatitudeTextCtrlSourceM.SetBackgroundColour(self.disabled_color)
            self.LatitudeTextCtrlSourceS.SetBackgroundColour(self.disabled_color)
            self.LongitudeTextCtrlSourceD.SetBackgroundColour(self.disabled_color)
            self.LongitudeTextCtrlSourceM.SetBackgroundColour(self.disabled_color)
            self.LongitudeTextCtrlSourceS.SetBackgroundColour(self.disabled_color)
            self.HeightTextCtrlSourceDMS.SetBackgroundColour(self.disabled_color)

    def setIsi(self, Lat, Long, Height):
        LatDMS = DD2DMS(Lat)
        LongDMS = DD2DMS(Long)
        self.LatitudeTextCtrlSourceDD.SetValue(str(Lat))
        self.LongitudeTextCtrlSourceDD.SetValue(str(Long))
        self.HeightTextCtrlSourceDD.SetValue(str(Height))
        self.LatitudeTextCtrlSourceD.SetValue(str(LatDMS[0]))
        self.LatitudeTextCtrlSourceM.SetValue(str(LatDMS[1]))
        self.LatitudeTextCtrlSourceS.SetValue(str(LatDMS[2]))
        self.LongitudeTextCtrlSourceD.SetValue(str(LongDMS[0]))
        self.LongitudeTextCtrlSourceM.SetValue(str(LongDMS[1]))
        self.LongitudeTextCtrlSourceS.SetValue(str(LongDMS[2]))
        self.HeightTextCtrlSourceDMS.SetValue(str(Height))
        self.__changeNSDD(str(self.LatitudeTextCtrlSourceDD.GetValue()))
        self.__changeWEDD(str(self.LongitudeTextCtrlSourceDD.GetValue()))
        self.__changeNSDMS(str(self.LatitudeTextCtrlSourceD.GetValue()))
        self.__changeWEDMS(str(self.LongitudeTextCtrlSourceD.GetValue()))

    def okEvent(self, event):
        if self.IsModal():
            self.EndModal(event.EventObject.Id)
            self.applyValue()
        else:
            self.applyValue()
            self.Close()


    def applyEvent(self, event):
        self.applyValue()

    def applyValue(self):
        if self.degreesRadioBox.GetSelection() == 0:
            LatitudeCentral = math.fabs(float(self.LatitudeTextCtrlSourceDD.GetValue()))
            LongitudeCentral = math.fabs(float(self.LongitudeTextCtrlSourceDD.GetValue()))
            HeightCentral = float(self.HeightTextCtrlSourceDD.GetValue())
            if self.LatitudeNSDD.GetValue() == 'Selatan':
                LatitudeCentral=0-LatitudeCentral
            if self.LongitudeWEDD.GetValue() == 'Barat':
                LongitudeCentral=360-LongitudeCentral
        else:
            LatitudeCentral = math.fabs(float(self.LatitudeTextCtrlSourceD.GetValue())) + math.fabs(float(self.LatitudeTextCtrlSourceM.GetValue())/60) + math.fabs(float(self.LatitudeTextCtrlSourceS.GetValue())/3600)
            LongitudeCentral = math.fabs(float(self.LongitudeTextCtrlSourceD.GetValue())) + math.fabs(float(self.LongitudeTextCtrlSourceM.GetValue())/60) + math.fabs(float(self.LongitudeTextCtrlSourceS.GetValue())/3600)
            HeightCentral = float(self.HeightTextCtrlSourceDMS.GetValue())
            if self.LatitudeNSDMS.GetValue() == 'Selatan':
                LatitudeCentral=0-LatitudeCentral
            if self.LongitudeWEDMS.GetValue() == 'Barat':
                LongitudeCentral=360-LongitudeCentral

        self.parent_frame.SetCoordCentralValue(self.defaultCheckBox.GetValue(),self.degreesRadioBox.GetSelection(),LatitudeCentral,LongitudeCentral,HeightCentral)

    def clearAllTextSrc(self):
        self.LatitudeTextCtrlSourceDD.Clear()
        self.LatitudeTextCtrlSourceD.Clear() 
        self.LatitudeTextCtrlSourceM.Clear()  
        self.LatitudeTextCtrlSourceS.Clear() 
        self.LongitudeTextCtrlSourceDD.Clear() 
        self.LongitudeTextCtrlSourceD.Clear()  
        self.LongitudeTextCtrlSourceM.Clear()  
        self.LongitudeTextCtrlSourceS.Clear() 
        self.HeightTextCtrlSourceDD.Clear() 
        self.HeightTextCtrlSourceDMS.Clear()  

    def checkLayout(self):
        #check layout DD/DMS
        if self.degreesRadioBox.GetSelection() == 0:
             self.gridSizer1b.Show(self.gridSizer1bi)
             self.gridSizer1b.Hide(self.gridSizer1bii)           
        else:
             self.gridSizer1b.Hide(self.gridSizer1bi)
             self.gridSizer1b.Show(self.gridSizer1bii)           
        self.Layout()

    def checkNSDD(self, event):
        self.__changeNSDD('%s'%event.GetString())
        event.Skip()

    def checkNSDMS(self, event):
        self.__changeNSDMS('%s'%event.GetString())
        event.Skip()

    def checkWEDD(self, event):
        self.__changeWEDD('%s'%event.GetString())
        event.Skip()

    def checkWEDMS(self, event):
        self.__changeWEDMS('%s'%event.GetString())
        event.Skip()

    def __changeNSDD(self, stringZ):
        if len(stringZ) > 0:
            if stringZ[0] == "-":
                self.LatitudeNSDD.ChangeValue('Selatan')
            else:
                self.LatitudeNSDD.ChangeValue('Utara')

    def __changeWEDD(self, stringZ):
        if len(stringZ) > 0:
            if stringZ[0] == "-":
                self.LongitudeWEDD.ChangeValue('Barat')
            else:
                self.LongitudeWEDD.ChangeValue('Timur')

    def __changeNSDMS(self, stringZ):
        if len(stringZ) > 0:
            if stringZ[0] == "-":
                self.LatitudeNSDMS.ChangeValue('Selatan')
            else:
                self.LatitudeNSDMS.ChangeValue('Utara')

    def __changeWEDMS(self, stringZ):
        if len(stringZ) > 0:
            if stringZ[0] == "-":
                self.LongitudeWEDMS.ChangeValue('Barat')
            else:
                self.LongitudeWEDMS.ChangeValue('Timur')

    def cancel_button(self, event):
        if self.IsModal():
            self.EndModal(event.EventObject.Id)
        else:
            self.Close()

class FrameWithForms(wx.Frame):
    def __init__(self, *args, **kwargs):
        super(FrameWithForms, self).__init__(*args, **kwargs)
        notebook = wx.Notebook(self)
        self.form1 = FormWithSizer1(notebook)
        notebook.AddPage(self.form1, '&Koordinat Tunggal')

        self.CreateStatusBar() # A Statusbar in the bottom of the window

        # Setting up the menu.
        filemenu1= wx.Menu()
        keluar = wx.MenuItem(filemenu1,wx.ID_EXIT,"&Keluar\tCtrl+K","Keluar dari Aplikasi")
        keluar.SetBitmap(wx.Bitmap('img/exit.png'))
        menuExit = filemenu1.Append(keluar)        

        filemenu2= wx.Menu()
        opsi = wx.MenuItem(filemenu2,wx.ID_HELP,"&Opsi\tCtrl+O","Opsi Processing")
        opsi.SetBitmap(wx.Bitmap('img/opsi.png'))
        menuOptions= filemenu2.Append(opsi)
        
        filemenu3= wx.Menu()
        tentang = wx.MenuItem(filemenu3,wx.ID_ABOUT, "&Tentang\tCtrl+T","Tentang Aplikasi")
        tentang.SetBitmap(wx.Bitmap('img/about.png'))
        menuAbout= filemenu3.Append(tentang)        

        # Creating the menubar.
        menuBar = wx.MenuBar()
        menuBar.Append(filemenu1,"Ber&kas") # Adding the "filemenu1" to the MenuBar
        menuBar.Append(filemenu2,"&Alat") # Adding the "filemenu2" to the MenuBar
        menuBar.Append(filemenu3,"&Bantuan") # Adding the "filemenu3" to the MenuBar
        self.SetMenuBar(menuBar)  # Adding the MenuBar to the Frame content.

        # Events.
        self.Bind(wx.EVT_MENU, self.OnExit, menuExit)
        self.Bind(wx.EVT_MENU, self.OnOptions, menuOptions)
        self.Bind(wx.EVT_MENU, self.OnAbout, menuAbout)
       
        # We just set the frame to the right size manually. This is feasible
        # for the frame since the frame contains just one component. If the
        # frame had contained more than one component, we would use sizers
        # of course, as demonstrated in the FormWithSizer class above.
        self.SetClientSize(notebook.GetBestSize())

    def OnAbout(self,e):
        # Create a message dialog box
        dlg = wx.MessageDialog(self, " © Copyleft 2019 \n Perangkat Lunak Bad Computation \n dibuat oleh Kelompok Keilmuan Geodesi ITB", "About", wx.OK)
        dlg.ShowModal() # Shows it
        dlg.Destroy() # finally destroy it when finished.

    def OnOptions(self,e):
        # Create a message dialog box
        #dlg = wx.MessageDialog(self, "Nanti disini dikasih opsi2", "Options", wx.OK)
        #dlg = MyDialog(None, title='Opsi')
        self.dlg = OptionsDialog(self.form1, title='Opsi')
        self.dlg.ShowModal() # Shows it
        self.dlg.Destroy() # finally destroy it when finished.
        #self.options_frame = OptionsDialog(self,)
        #self.options_frame.Show()

    def OnExit(self,e):
        self.Close(True)  # Close the frame.

if __name__ == '__main__':
    app = wx.App(0)
    frame = FrameWithForms(None, title='Bad Computation')
    frame.Show()
    ico = wx.Icon('img/icon.ico', wx.BITMAP_TYPE_ICO)
    frame.SetIcon(ico)
    app.MainLoop()
